# Jellyfin VGMdb Concerts

[English](README.md) | [简体中文](README.zh-CN.md)

面向 Jellyfin 12.1 / .NET 10 的日本演唱会电影元数据与封面插件，适用于 Blu-ray、DVD 和直播归档。可与 Jellyfin 官方 VGMdb 音乐插件共存；本插件不注册音乐专辑或艺术家提供程序。

## 来源优先级

1. 演唱会活动始终先查询 Bangumi。候选条目必须是标题经过验证、年份相符的“演出”；Day 录像还必须找到对应剧集。只有年份相符且候选唯一时，才接受具有较长共同片段的标题。若英日文标题完全不同，可选的 Wikidata 别名查询会再次搜索 Bangumi；Wikidata 不提供元数据或图片。复用已有 Bangumi ID 前也会验证。
2. Bangumi 提供活动标题、原标题、演出日期、简介、标签、场地、外部链接和主封面。各 Day 保持独立电影；共享合集身份取自演唱会文件夹，不因条目本地化标题改变。分碟标题保留各巡演分场名称，重复的 Day 编号通过录制日期或碟号区分。
3. VGMdb 补充匹配的商业发行信息，包括目录编号、载体格式、制作公司、表演者、发行日期标签和发行版 ID。依次尝试 Bangumi 的各尺寸图片后仍失败时，才将 VGMdb 封面用作备用主图。VGMdb 不覆盖有效的 Bangumi 活动标题、日期或主封面。
4. Bangumi 无法验证匹配或网络不可用时，合适的 VGMdb 演唱会视频发行版仍可作为后备结果。两者均未匹配时，明确标注的 Day 归档和演唱会文件夹保留本地后备元数据。普通电影不会仅因路径类似演唱会而被认领。

插件会过滤 Bangumi 默认占位图和无效图片 URL，并依次尝试 `large`、`common`、`medium` 尺寸。两个服务均使用有界并发、成功响应缓存、取消传播和临时故障冷却。VGMdb 使用社区维护的 JSON API；其网络故障不会丢弃有效的 Bangumi 匹配。

手动计划任务“修复 VGMdb Concerts 合集与封面”仅处理本插件管理的电影和合集：复用匹配的 Jellyfin 合集，删除经确认由插件创建的重复合集，清理非演唱会表演者的演职人员，并直接保存首选封面；修复过程本身不会触发视频取帧。此任务没有自动触发器。插件电影下载元数据后只清理该条目的人员；若不在媒体库扫描期间，还会补存封面。手动任务运行时会抑制逐项监听器，避免同时写入同一张图。封面修复可能替换手动选择的主图，人员清理会移除插件电影中非 `Performer` 的人员；其它媒体库条目不受影响。两个服务都没有有效图片时，插件无法凭空生成海报，Jellyfin 可能显示视频截帧。

## 插件选项

配置页位于 **控制台 → 插件 → VGMdb Concerts**，随 Jellyfin 界面语言显示英文或简体中文，其他语言回退为英文。Bangumi 优先是固定规则，不能关闭。

| 选项 | 默认值 | 作用 |
| --- | --- | --- |
| Bangumi API / 网站地址 | `https://api.bgm.tv` / `https://bgm.tv` | API 请求和条目链接。 |
| VGMdb API / 网站地址 | `https://vgmdb.info` / `https://vgmdb.net` | 补充发行信息和外部链接。 |
| 请求超时 | 15 秒 | 每次网络尝试；范围为 1 至 300 秒。 |
| HTTP 代理 | 空 | 仅供本插件使用的可选代理。 |
| 查询缓存 | 开启 | 合并并发请求，在容量受限的进程内缓存成功响应。 |
| 跨语言标题别名 | 开启 | Bangumi 无法验证英文标题时，从 Wikidata 查询日文别名并重试 Bangumi；可关闭以避免额外对外请求。 |
| AnitomySharp 自动标题解析 | 关闭 | 为 VGMdb 增加解析后的标题查询；显式 Day 解析不依赖它。 |
| 信任已有的 Bangumi 官方插件 ID | 关闭 | 仅在条目类型、标题、年份和 Day 验证后复用。 |
| 演唱会附加内容后备识别 | 开启 | 识别 Day 分碟、其它具名碟片、幕后内容和特典；匹配活动后仍保留各碟片的本地标题。 |
| 活动归档后备识别 | 开启 | 将未收录的 Day 归档和独立活动保留为本地演唱会电影。 |

建议使用电影媒体库，每场演唱会一个文件夹；归档文件名保留明确的 `Day 1` / `Day 2` 和 `Archive` / `アーカイブ` 标记。升级后先完成媒体库扫描，再到 **控制台 → 计划任务 → VGMdb Concerts → 修复 VGMdb Concerts 合集与封面**（英文界面为 **Repair VGMdb Concerts collections and artwork**）手动运行一次，以清理现有的错误演职人员并重试电影封面。此后仅在合集成员或封面需要修复时再次运行；普通扫描不再执行全量修复。扫描外的单个条目元数据刷新仍会补存封面。若封面仍缺失，请检查 `api.bgm.tv` 和 `lain.bgm.tv` 的连通性。Jellyfin 的“替换现有的进度条预览图”只影响播放预览，不是封面选项；勾选它还可能触发独立的视频处理。若日志出现 NFO 或图片写入权限错误，请关闭将元数据保存到媒体文件夹的选项，或授予 Jellyfin 对该目录的写入权限。

## 安装

在 Jellyfin 的 **插件 → 存储库 → 添加** 中，将名称设为 `VGMdb Concerts`，地址设为：

```text
https://wym3253.github.io/jellyfin-plugin-vgmdb-concerts-repository/repository.json
```

然后从 **目录** 安装 **VGMdb Concerts** 并重启 Jellyfin。若 GitHub Pages 不可用，可使用原始清单地址：

```text
https://raw.githubusercontent.com/wym3253/jellyfin-plugin-vgmdb-concerts-repository/main/repository.json
```

存储库地址保持不变；每次发布都会更新清单中对应的版本化 ZIP 下载链接和校验和。源码与发布文件见 [wym3253/jellyfin-plugin-vgmdb-concerts](https://github.com/wym3253/jellyfin-plugin-vgmdb-concerts)。

## 开发

本插件基于 [jellyfin/jellyfin-plugin-vgmdb](https://github.com/jellyfin/jellyfin-plugin-vgmdb)。仓库保留上游音乐插件源码以便同步，但独立电影程序集不会编译这些音乐提供程序。编译、测试和发布打包仅使用手动触发的 GitHub Actions 工作流，不在本地编译或测试。
