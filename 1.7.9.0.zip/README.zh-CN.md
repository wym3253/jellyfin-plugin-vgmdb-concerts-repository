# Jellyfin VGMdb Concerts

[English](README.md) | [简体中文](README.zh-CN.md)

这是一个独立的 Jellyfin 10.11 元数据提供程序，用于整理 VGMdb 收录的日本演唱会 Blu-ray 和 DVD。

`VGMdb Concerts` 拥有独立的插件 GUID、程序集、提供程序名称和电影外部 ID，可以与 Jellyfin 官方 `VGMdb` 音乐插件同时安装。本插件不会注册艺术家或音乐专辑提供程序。

## 演唱会电影功能

- 在 Jellyfin **电影**媒体库中搜索 VGMdb 专辑。
- 自动匹配时只保留同时具有现场与视频信号的发行版。
- 写入标题、日文原名、发行日期、简介、类型、制作公司、目录编号、介质格式和发行格式。
- 将 VGMdb 表演者映射为 Jellyfin 人员，使同一表演者可以关联多场演唱会。
- 提供主封面和可点击的 VGMdb 电影外部 ID。
- 媒体库元数据语言为 `ja` 时优先使用日文名称，否则优先使用罗马字和英文名称。
- 支持 `[vgmdbid-116768]` 这样的精确文件夹或文件提示。
- 优先排列目录编号匹配，其次是精确标题、年份和部分标题匹配。
- 对剩余结果按日文、罗马字、英文和后备标题中的最佳 Levenshtein 相似度进行模糊排序。
- 可选使用 AnitomySharp 从自动扫描的电影文件名中提取额外查询。此功能默认关闭，不解析手动搜索或显式 VGMdb ID；原始查询仍会保留，重复发行版会合并，并在应用原有排序规则前降低解析标题匹配的置信度。
- 默认将成功的 VGMdb 和 Bangumi 搜索及详情请求保存在容量受限的内存缓存中。相同并发请求会合并；成功条目最长保留七天，滑动过期时间为六小时；失败响应不会缓存。VGMdb 传输失败会触发两分钟冷却，避免媒体库扫描为每个文件重复请求无法访问的主机。
- 默认使用高置信度的 Bangumi 演出条目补充成功的 VGMdb 匹配。商业发行版的身份、标题、日期、目录数据、格式和主封面仍以 VGMdb 为准；Bangumi 可补充活动简介、活动日期标签、场地、标签、已识别 Day 的合集名称、ID、链接和横向图片。Bangumi 的网络、JSON、超时或置信度失败不会改变完整的 VGMdb 结果。
- 可选为未收录的活动录像启用后备识别，包括多日直播归档和独立演唱会文件夹。此功能默认关闭，只在 VGMdb 没有返回合适的演唱会视频或不可用时运行。多日归档的电影标题必须同时包含明确的 Day 编号和 Archive/アーカイブ 标记；自动扫描和元数据刷新可使用后备识别，手动“识别”搜索不会解析。若其他提供程序已规范化显示标题并移除标记，自动刷新会从源文件名恢复。各 Day 仍是独立电影并共用合集名称，插件不会虚构 VGMdb ID 或商业发行元数据。
- 默认在自动扫描和元数据刷新期间识别本地演唱会附加文件，不改变手动“识别”搜索。普通 Day 分碟仍优先使用合适的 VGMdb 发行版；Making of、backstage、メイキング、舞台裏、幕后和花絮文件分类为 `BehindTheScenes`；带有明确 bonus、documentary、vacation 或特典信号的编号分碟分类为 `Featurette`。这些条目仍是独立可播放的电影，并继承清理后的演唱会文件夹合集身份。
- 可选使用 Bangumi 演出条目丰富归档后备结果；该开关同样默认关闭。只接受年份兼容、剧集覆盖充分且置信度高的 `演出` 类型匹配。独立活动保持单个电影身份，不会虚构 Day 后缀或合集。Bangumi 可提供活动日期、简介、各日表演者和歌单、场地、横向图片、标签、条目/剧集 ID 和外部链接。网络、JSON 或置信度失败时保留纯本地后备结果，不会让元数据刷新失败。
- 为生成的演唱会 `BoxSet` 合集提供类似 TMDb 的元数据。仅接受成员已由 VGMdb Concerts 识别的合集，写入独立稳定的合集 ID，并从成员中汇总合集标题、简介、最早活动日期、年份、类型、制作公司和合集标签。

VGMdb 描述的是商业视频发行版，不一定是原始演出日期或场地。这些活动级字段可留给未来的 LiveFans 或本地 NFO 集成。

## 插件选项

插件配置位于 **控制台 → 插件 → VGMdb Concerts**。配置页会跟随 Jellyfin 的界面语言自动显示英文或简体中文；其他语言回退为英文。

| 选项 | 默认值 | 作用 |
| --- | --- | --- |
| 缓存成功的 VGMdb 和 Bangumi 查询 | 开启 | 合并相同并发请求并缓存成功结果；关闭后也会关闭 VGMdb 失败冷却。 |
| 使用 AnitomySharp 自动解析文件名搜索 | 关闭 | 从带发布组、分辨率、编码或来源标签的文件名中提取额外标题查询，不影响手动搜索和显式 VGMdb ID。 |
| 使用 Bangumi 补充成功的 VGMdb 匹配 | 开启 | 为可靠的 VGMdb 匹配补充活动简介、日期、场地、标签、合集、链接和横向图片，发行版核心字段仍以 VGMdb 为准。 |
| 识别演唱会分碟、幕后花絮和特典内容 | 开启 | 使用演唱会父文件夹识别 Day 分碟、Making of、幕后和特典文件，并保留为独立可播放电影。 |
| 将未收录的多日演唱会归档分组为合集 | 关闭 | 在 VGMdb 无合适结果时识别带 Day 与 Archive 标记的录像，保持各 Day 独立并分入同一合集。 |
| 使用 Bangumi 丰富活动归档元数据 | 关闭 | 依赖上一项；仅接受高置信度且年份和剧集覆盖符合要求的 Bangumi 演出条目。 |

## 推荐的 Jellyfin 布局

创建一个电影媒体库，每个演唱会发行版放在单独文件夹中：

```text
Concerts/
└── THE IDOLM@STER SHINY COLORS 3rdLIVE TOUR NAGOYA (2022) [vgmdbid-116768]/
    └── THE IDOLM@STER SHINY COLORS 3rdLIVE TOUR NAGOYA (2022) [vgmdbid-116768].mkv
```

若希望使用日文标题和表演者名称，请将媒体库的首选元数据语言设为日语。在媒体库元数据提供程序设置中按需启用 **VGMdb Concerts** 并调整顺序。

AnitomySharp 解析器最适合文件名包含发布组、分辨率、编码和来源标签的情况。若演唱会标题含有应原样发送给 VGMdb 的特殊编号，请保持关闭。

从 1.7.9 起，每个插件选项均提供英文和简体中文配置文本。配置页会自动跟随 Jellyfin 当前的界面语言，其他语言回退为英文。

活动归档后备识别可让下列自动电影标题保持为独立条目，同时加入共享合集 `THE IDOLM@STER SHINY COLORS LIVE FUN!! -Beyond the Blue sky-`：

```text
THE IDOLM@STER SHINY COLORS LIVE FUN!! -Beyond the Blue sky- Day 1 (アーカイブ)
THE IDOLM@STER SHINY COLORS LIVE FUN!! -Beyond the Blue sky- Day 2 (アーカイブ)
```

从 1.7.8 起，当没有匹配的 VGMdb 演唱会视频发行版时，同一可选后备机制也适用于独立演唱会文件夹。例如，`Ave Mujica 0th LIVE「Primo die in scaena」` 可匹配高置信度 Bangumi `演出` 条目，并获得本地化标题、原标题、日期、简介、标签、ID、链接和图片。匹配逻辑保持通用，生产代码未内置艺术家、演唱会标题或 Bangumi 条目 ID。发布组和技术参数方括号会先移除；Bangumi、网络或置信度失败时保留清理后的本地演唱会元数据。已有独立电影首次采用该身份时会执行一次完整元数据刷新，即使已有图片；后续扫描不会反复覆盖用户元数据。

插件不会安装第二个文件系统监视器。Jellyfin 媒体库的 **启用实时监控** 负责监视支持的文件夹并启动增量扫描；VGMdb Concerts 作为电影提供程序参与处理，然后在扫描后修复合集和身份。这样可避免重复监视和重复扫描。网络共享或无法提供变更通知的文件系统应继续启用 Jellyfin 定时媒体库扫描。

从 1.7.5 起，电影与合集图片均可复用 Bangumi 官方插件写入的数字 `Bangumi` ID。若合集成员仍没有远程图片身份，合集图片提供程序会使用规范合集标题和年份自行搜索 Bangumi 演出，并执行与元数据相同的活动类型和标题置信度检查。升级后，生成的合集会一次性重置过期图片。该行为是通用合集逻辑，生产代码未内置艺术家、巡演、场次或条目 ID。

从 1.7.4 起，Bangumi infobox 可同时接受标量和结构化数组值，IWSF 等活动条目不再导致反序列化中止。普通 Day 附加条目使用与归档文件相同的可选 Bangumi 丰富和置信度检查；已有数字 Bangumi 条目 ID 在验证活动类型、年份和 Day 覆盖后可复用。VGMdb Concerts 对其管理的电影图片具有第一优先级。升级后的首次扫描中，拥有可信 VGMdb/Bangumi 身份的本地后备演唱会会丢弃无关 IMDb/TMDb/TVDb 身份并刷新一次图片，以替换此前保存的演员拼图或视频帧海报；之后不会反复覆盖用户选择。

从 1.7.3 起，可识别 `FES`、`フェス`、`歌合戦` 等通用庆典标记，从带日期的发行文件夹恢复活动年份，并接受 `DAY1 SW`、`DAY1 定点` 等流版本前的 Day 标记。发布组和编码标签不再进入电影标题。若专辑级 VGMdb 匹配曾让所有分碟得到相同发行标题，扫描后修复也会恢复各场次标题，例如 `Brilliant Blooms Day 1`。

从 1.7.2 起，最近的演唱会父文件夹作为稳定合集身份。Bangumi 补充可以本地化单个电影标题，但不再替换合集身份或创建第二个合集。例如，位于 `[260425-26] THE IDOLM@STER SHINY COLORS ∞th LIVE iと夢 (ASOBI)` 下的 `シャイニーカラーズ8th Day 1（アーカイブ）` 会归入清理后的规范合集 `THE IDOLM@STER SHINY COLORS ∞th LIVE iと夢`。`Brilliant Blooms Day 1` 等更具体的文件标题仍是单个电影标题，同一发行文件夹下的所有分碟和制作花絮共用一个合集。自动 VGMdb 匹配除具体文件标题外，也会查询该稳定父发行名称。

附加内容后备识别默认开启。它会穿过中间的 `Disc N` 文件夹寻找最近的演唱会根目录，因此 `Disc 3/Making of ... Day 1.mkv` 会标记为幕后内容，`Disc 7 - Shinymas's Summer Vacation in Okinawa.mkv` 会标记为特辑。显式 VGMdb ID 始终具有最高优先级。若条目此前被其他提供程序错误识别，请执行一次 **替换所有元数据** 刷新，避免陈旧提供程序 ID 保留错误的手动识别结果。

电影媒体库还必须启用 **自动添加到合集**。至少两个具有相同生成合集名称的电影完成元数据刷新，并随后执行一次完整媒体库扫描后，Jellyfin 才会创建合集。单独执行 **刷新元数据** 只会写入 `CollectionName`，不会运行 Jellyfin 的 `CollectionPostScanTask`，因此请刷新两个 Day 条目后再执行一次 **扫描所有媒体库**。Day 文件在生成的合集中仍是独立可播放电影，不会被视作同一电影的备用版本。

每次完整扫描后，插件会按照稳定文件夹身份协调已识别的演唱会电影：将成员移出过时的插件生成的逐文件合集，在过时合集为空后删除它，并在要求 Jellyfin 刷新图片前清理所引用文件已不存在的本地图片数据库记录。

独立的 Bangumi 丰富开关只在归档后备逻辑中使用 Bangumi，不会取代 VGMdb 对商业 Blu-ray/DVD 发行版的处理。插件会同时发送原始活动标题和简化标点后的额外查询，再按条目 ID 合并候选。结果仅限活动条目，并按规范化标题、年份和剧集覆盖在本地排序，然后获取所选 Day。插件发送 Bangumi API 要求的可识别、带版本 User-Agent。若 Bangumi 不可用或两个查询都未通过置信度检查，电影仍会从归档后备逻辑获得本地标题、年份、类型、标签和合集名称。此前只由纯本地后备识别的电影会在下次元数据刷新时原位丰富，无需删除元数据或重新导入文件。

查询缓存沿用 Bangumi Jellyfin 插件的成功响应缓存策略，并增加进行中请求合并与短暂 VGMdb 失败冷却。缓存只存在于当前进程，最多 512 个条目，Jellyfin 重启时清空，可在 **控制台 → 插件 → VGMdb Concerts** 中关闭；关闭缓存也会关闭冷却。

Jellyfin 将交互式 **刷新元数据** 标记为非自动请求；插件会明确处理该刷新路径，但不会在手动 **识别** 搜索结果列表中暴露解析出的归档后备条目。从 1.5.2 起，若保存的显示标题已不含 `Day` 和 `アーカイブ`，该刷新会重新读取源文件名，以应对其他元数据提供程序重命名条目的情况。`生放送` 文件不符合归档后备条件，仍是独立电影。

图片选择会考虑图片槽位：主图片优先使用 VGMdb 发行封面，背景图和缩略图优先使用 Bangumi 活动图片。若某来源没有所需形状的图片，可用图片也会提供给该槽位，由 Jellyfin 裁剪为目标卡片形状。本地 `poster`、`landscape` 和 `backdrop` 文件仍优先于远程提供程序。

自动创建的合集是独立 `BoxSet` 条目，不会继承电影的元数据或图片。参考 Jellyfin 的 TMDb BoxSet 设计，VGMdb Concerts 会先识别并填充范围严格限定的演唱会合集，再解析图片。远程 VGMdb/Bangumi 图片仍然优先；若两者没有可用图片，动态后备会复用首个已识别成员电影中已下载的本地图片。主图片、背景图和缩略图继续按槽位选择并提供裁剪后备。更新插件后，请对合集执行一次元数据和图片刷新。

## 安装

推荐按照 Jellyfin 插件仓库流程安装，且只使用 GitHub：

1. 在 Jellyfin 控制台中打开 **插件 → 存储库**，选择 **添加**。
2. 将存储库名称设为 `VGMdb Concerts`。
3. 将存储库 URL 设为：

   ```text
   https://wym3253.github.io/jellyfin-plugin-vgmdb-concerts-repository/repository.json
   ```

4. 保存，打开 **目录**，找到并安装 **VGMdb Concerts**。
5. 安装或更新后重启 Jellyfin。

通过目录安装可让 Jellyfin 发现该仓库后续发布的版本。私有源代码仓库只会通过 GitHub Pages 向专用公开仓库发布目录清单和编译后的 ZIP。若某些网络无法使用 GitHub Pages，可使用原始 GitHub URL：

```text
https://raw.githubusercontent.com/wym3253/jellyfin-plugin-vgmdb-concerts-repository/main/repository.json
```

插件仓库 URL 是稳定地址，不会随版本变化。`master` 上带版本号的提交通过 **Build and test** 工作流后，
**Sync upstream** 会自动创建 GitHub Release，并重新生成公开仓库的 `repository.json`、校验和及版本化下载
地址。Jellyfin 随后可通过同一个安装 URL 发现新版本，无需手动修改清单。

## 构建与测试

插件目标为 .NET 9 和 Jellyfin 10.11。GitHub Actions 会对每次 push 和 pull request 执行权威构建：

1. 打开仓库的 **Actions** 页面。
2. 选择最近一次成功的 **Build and test** 运行。
3. 下载 `Jellyfin.Plugin.Vgmdb-Concerts-*` 构件。
4. 将 `Jellyfin.Plugin.VgmdbConcerts.dll` 复制到 Jellyfin 插件目录下的独立文件夹，然后重启 Jellyfin。

工作流会还原依赖、以 Release 模式运行完整测试项目、发布插件，并保留可下载构件 30 天；也可通过 **Run workflow** 手动启动。

## 数据源说明

本插件使用社区运营的 `vgmdb.info` JSON API，因为 VGMdb 没有发布官方 API。可选的活动归档丰富功能使用无需登录的官方 [Bangumi API](https://bangumi.github.io/api/)，并在 User-Agent 中提供项目标识。服务可用性、用户贡献的元数据、图片托管和上游架构变化不受本插件控制。

## 上游与许可证

项目基于 [jellyfin/jellyfin-plugin-vgmdb](https://github.com/jellyfin/jellyfin-plugin-vgmdb)。仓库保留完整的上游运行时源代码，以便正常拉取和合并上游。项目文件会从独立程序集排除上游艺术家/音乐专辑发现类型及上游插件入口点。编译后的 DLL 会注册电影元数据、图片、外部 ID 和外部 URL 提供程序，仅为由已识别演唱会电影生成的 BoxSet 注册元数据及图片提供程序，并运行仅限这些已识别电影和受管理 BoxSet 的扫描后修复；不会注册任何艺术家或音乐专辑提供程序。

`upstream` 远端仅用于获取。同步方式：

```powershell
git fetch upstream master
git merge upstream/master
```

GitHub Actions 的 **Sync upstream** 工作流会每天日本时间 00:17 检查上游变化，并支持手动启动。它会合并 `upstream/master`、增加独立补丁版本、还原依赖并运行完整测试套件，然后才推送到本仓库的 `master`。它也会在 `master` 的 **Build and test** 成功后自动运行，发布尚无 Release 的版本并刷新公开插件仓库。没有上游更新时不会创建合并提交；合并冲突或测试失败会停止工作流且不会推送。

发布使用仓库的 `VERSION` 文件和 `concerts-v1.0.0` 这样的独立标签，避免与继承自上游的标签冲突。每次带版本号的 `master` 构建成功后，工作流会将当前版本发布为带版本 ZIP 包的 GitHub Release，并更新稳定安装清单。手动重新运行还可补齐当前版本缺失的 Release 或修复过期清单，而不会创建新的源代码提交。若 `VERSION`、程序集版本和 `build.yaml` 不一致，工作流会拒绝发布。

合并后，测试会检查编译程序集的发现表面；若注册了上游艺术家/音乐专辑提供程序或未获批准的发现类型，测试将失败。唯一允许的 BoxSet 元数据提供程序就是上述按演唱会成员限制范围的提供程序。独立插件名称、程序集名称、GUID 和电影外部 ID 键始终与官方插件分离。

本项目采用 GPL-3.0 许可证。
