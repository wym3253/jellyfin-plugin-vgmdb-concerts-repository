# Jellyfin VGMdb Concerts

[English](README.md) | [简体中文](README.zh-CN.md)

面向 Jellyfin 12.1 / .NET 10 的日本演唱会电影元数据与封面插件，适用于 Blu-ray、DVD 和直播归档。可与 Jellyfin 官方 VGMdb 音乐插件共存；本插件不注册音乐专辑或艺术家提供程序。

## 来源优先级

1. 演唱会活动始终先查询 Bangumi。候选条目必须是标题经过验证、年份相符的“演出”；Day 录像还必须找到对应剧集。搜索会提取引号、连字符和冒号分隔的普通副标题，不使用针对特定演出的规则。具有较长共同片段的标题必须有年份佐证且候选唯一；不同的同语言副标题、最高分相同的多个候选不会被自动接受。明确的录制日期或标题中的演出年份必须严格一致。文件夹发行日期和未验证的媒体年份只作为较弱线索，允许演出早于它们最多六年，但不能覆盖明确的演出年或消除候选歧义。若英日文标题完全不同，可选的 Wikidata 别名查询会再次搜索 Bangumi；Wikidata 不提供元数据或图片。复用已有 Bangumi ID 前也会验证。
2. Bangumi 提供活动标题、原标题、演出日期、简介、标签、场地、外部链接和主封面。各 Day 保持独立电影；共享合集身份取自演唱会文件夹，不因条目本地化标题改变。分碟标题保留各巡演分场名称，重复的 Day 编号通过录制日期或碟号区分。
3. 开启**启用 VGMdb**后，VGMdb 补充匹配的商业发行信息，包括目录编号、载体格式、制作公司、表演者、发行日期标签和发行版 ID。依次尝试 Bangumi 的各尺寸图片后仍失败时，才将 VGMdb 封面用作备用主图。VGMdb 不覆盖有效的 Bangumi 活动标题、日期或主封面。
4. Bangumi 无法验证匹配或网络不可用时，合适的 VGMdb 演唱会视频发行版仍可作为后备结果。两者均未匹配时，明确标注的 Day 归档和演唱会文件夹保留本地后备元数据。普通电影不会仅因路径类似演唱会而被认领。

插件会过滤 Bangumi 默认占位图和无效图片 URL，并依次尝试 `large`、`common`、`medium` 尺寸。两个服务均使用有界并发、成功响应缓存、取消传播和临时故障冷却。上游音乐插件已因 `vgmdb.info` 关闭而归档。VGMdb 补充功能需要在本插件中配置可用的兼容 API；其故障不会丢弃有效的 Bangumi 匹配，也不会阻止获取 Bangumi 封面。

手动计划任务“修复 VGMdb Concerts 合集与封面”仅处理本插件管理的电影和合集：复用匹配的 Jellyfin 合集，删除经确认由插件创建的重复合集，清理非演唱会表演者的演职人员，并直接保存首选封面；修复过程本身不会触发视频取帧。此任务没有自动触发器。插件电影下载元数据后会清理该条目的人员并补存封面；Jellyfin 图片更新通知也会触发该电影的缺失封面恢复，无需再次下载元数据，这一路径会保留已有的有效主图。媒体库扫描期间，只把受影响电影的封面请求延后到扫描结束，并再次检查缺失封面是否仍需恢复，不执行全库修复。手动任务运行时会抑制逐项监听器，并使之前排队的旧请求失效，避免同时写入或旧请求覆盖新结果。显式元数据刷新和手动封面修复可能替换手动选择的主图，人员清理会移除插件电影中非 `Performer` 的人员；其它媒体库条目不受影响。只有确认本地图片文件存在且非空后才报告保存成功，随后通知 Jellyfin 图片已更新。两个服务都没有有效图片时，插件无法凭空生成海报，Jellyfin 可能显示视频截帧。

## 插件选项

配置页位于 **控制台 → 插件 → VGMdb Concerts**，随 Jellyfin 界面语言显示英文或简体中文，其他语言回退为英文。Bangumi 优先是固定规则，不能关闭。

| 选项 | 默认值 | 作用 |
| --- | --- | --- |
| 启用 VGMdb | 开启 | 控制 VGMdb 发行信息补充、后备匹配和备用封面；关闭后使用 Bangumi 与本地演唱会识别，不发送 VGMdb API 请求，也不使用其缓存结果。 |
| Bangumi API / 网站地址 | `https://api.bgm.tv` / `https://bgm.tv` | API 请求和条目链接。 |
| VGMdb API / 网站地址 | `https://vgmdb.info` / `https://vgmdb.net` | 补充发行信息和外部链接。 |
| 请求超时 | 15 秒 | 每次网络尝试；范围为 1 至 300 秒。 |
| HTTP 代理 | 空 | 仅供本插件使用的可选代理。 |
| 查询缓存 | 开启 | 合并并发请求，在容量受限的进程内缓存成功响应。 |
| 跨语言标题别名 | 开启 | Bangumi 无法验证英文标题时，从 Wikidata 查询日文别名并重试 Bangumi；可关闭以避免额外对外请求。 |
| AnitomySharp 自动标题解析 | 关闭 | 为 VGMdb 增加解析后的标题查询；显式 Day 解析不依赖它。 |
| 信任已有的 Bangumi 官方插件 ID | 关闭 | 仅在条目类型、标题、年份和 Day 验证后复用。 |
| 本地演唱会标题映射 | 留空 | 为无法自动匹配的文件夹标题指定 Bangumi 条目；格式、示例和现有媒体库的更新步骤见[本地演唱会标题映射](#本地演唱会标题映射)。 |
| 演唱会附加内容后备识别 | 开启 | 识别 Day 分碟、其它具名碟片、幕后内容和特典，包括无编号的 `SPECIAL DISC`、`Bonus01`、`Menu01`；匹配活动后仍保留各碟片或附加文件的本地标题。特典和菜单使用活动封面，不要求对应 Day 剧集。 |
| 活动归档后备识别 | 开启 | 将未收录的 Day 归档和独立活动保留为本地演唱会电影。 |

VGMdb 服务不可用时，取消勾选 **控制台 → 插件 → VGMdb Concerts → 启用 VGMdb**并保存。后续查询立即采用新设置，无需重启；已经发出的请求可能继续完成。Bangumi 搜索、Wikidata 别名、标题映射、Day/特典识别以及合集与封面修复继续运行。保存开关不会删除已有元数据、提供程序 ID 或图片文件。关闭期间，即使已有 VGMdb ID 或缓存，也不会为新查询提供仅 VGMdb 拥有的发行信息及备用封面；配置可用的兼容 API 后重新开启即可恢复这些可选功能。AnitomySharp 的附加 VGMdb 查询也随之跳过。

建议使用电影媒体库，每场演唱会一个文件夹；归档文件名保留明确的 `Day 1` / `Day 2` 和 `Archive` / `アーカイブ` 标记。升级后先完成媒体库扫描，再到 **控制台 → 计划任务 → VGMdb Concerts → 修复 VGMdb Concerts 合集与封面**（英文界面为 **Repair VGMdb Concerts collections and artwork**）手动运行一次，以清理现有的错误演职人员并重试电影封面。此后仅在合集成员或封面需要修复时再次运行；普通扫描不再执行全量修复。扫描外的单个条目元数据刷新仍会补存封面。若封面仍缺失，请检查 `api.bgm.tv` 和 `lain.bgm.tv` 的连通性。Jellyfin 的“替换现有的进度条预览图”只影响播放预览，不是封面选项；勾选它还可能触发独立的视频处理。若日志出现 NFO 或图片写入权限错误，请关闭将元数据保存到媒体文件夹的选项，或授予 Jellyfin 对该目录的写入权限。

若已保存的封面后来消失，请检查 Jellyfin 元数据目录是否可写、重启后是否持久保留，以及是否有外部清理删除图片文件。合集封面和成员电影封面是独立文件；保存成功日志会包含每个条目的实际图片路径。缺失图片通知会触发按条目恢复；若文件在 Jellyfin 空闲期间被删除，需要媒体库扫描或手动修复任务才能发现。

## 本地演唱会标题映射

当罗马字或翻译后的演唱会文件夹名无法通过 Bangumi、Wikidata 验证，而你已知道正确的 Bangumi“演出”条目时，可以使用此配置。插件不内置任何演出映射。

1. 打开 **控制台 → 插件 → VGMdb Concerts → 本地演唱会标题映射**。
2. 每行填写一条：`清理后的演唱会文件夹名称 = Bangumi 条目链接或 ID`。左侧取媒体路径中的演唱会文件夹名，不是 Jellyfin 翻译后的显示名称或单个视频文件名。例如，`[Release] City Orchestra Winter LIVE [BDRip 1080p]` 应填写为 `City Orchestra Winter LIVE`。去掉发布组和媒体格式标签，但保留演唱会标题本身的标点、副标题；不要添加文件级的 `Day 1`、`Bonus01`、`Menu01` 后缀。
3. 点击**保存**。映射修改会在后续元数据请求中生效，无需重启 Jellyfin；安装插件新版后仍需重启。
4. 更新已有媒体库时，先等待媒体库扫描结束，再手动运行一次 **控制台 → 计划任务 → VGMdb Concerts → 修复 VGMdb Concerts 合集与封面**。此任务会刷新映射尚未应用或目标 ID 已变更的电影，修正编号附加内容身份，更新合集成员，并刷新受影响合集的元数据和封面。新加入的条目会在正常查询元数据时使用映射。

下面示例配置了两场不同演唱会，分别使用链接和纯数字 ID：

```text
City Orchestra Winter LIVE = https://bangumi.tv/subject/12345
Harbor Ensemble Summer Concert = 67890
```

上面的标题、ID 只是格式示例，必须替换为实际文件夹名和已核实的条目。输入普通文本即可，不要添加 JSON、引号或 Markdown 代码块标记。一条映射覆盖该演唱会文件夹的全部 Day、特典、菜单和合集，无需为每个文件重复填写。

标题匹配忽略大小写、Unicode 宽度和连续空白差异，其余部分必须与清理后的完整文件夹名相同。右侧支持正整数条目 ID，或 `bangumi.tv`、`bgm.tv`、`chii.in` 的 HTTP/HTTPS `/subject/<id>` 链接；不能使用剧集的 `/ep/` 链接。不同文件夹标题可以指向同一条目。同一规范化标题若指向不同 ID，会被视为冲突而拒绝，不能通过配置多个 ID 来区分巡演分场。

映射只替代标题相似度验证：目标仍须为类型、年份相符的“演出”，Day 录像仍须有对应剧集；特典和菜单不要求 Day 剧集，直接使用活动封面。如果未生效，请核对实际文件夹名、目标条目、年份和 Day 编号。日志会提示无效/冲突映射或不相容的活动；映射无效时不会转而盲信旧 ID。

### 减少不必要的运行开销

- 保持**查询缓存**开启。同一条目和剧集分页的成功响应可由不同文件共享，并合并并发的重复请求。缓存保存在进程内，重启 Jellyfin 后需要重新获取。
- 有效映射直接获取指定条目，跳过 Bangumi 标题搜索和 Wikidata 别名查询；仍需获取、验证条目及剧集，仅在开启 VGMdb 时尝试其补充。映射本身不是离线元数据缓存。
- 对已有条目新增或修改映射后运行手动修复，此后仅在合集或封面需要修复时再次运行。映射 ID 未变不会仅因配置存在而强制再次全量刷新电影元数据。单个电影的问题优先刷新该条目；合集修复仍使用完整任务。应用映射、恢复海报均无需替换进度条预览图。
- 不需要发行信息补充或没有可用的兼容 API 时，关闭**启用 VGMdb**即可避免等待已关闭的默认 `vgmdb.info` 服务，同时保留 Bangumi 元数据与封面。仅将 API 地址留空仍会使用默认地址。启用 VGMdb 时，**请求超时**针对单次尝试，临时故障最多尝试三次，并非整个修复任务的最长耗时，且也影响 Bangumi 和封面请求。开启查询缓存后，临时故障会触发服务冷却，后续冷却警告不代表再次发送网络请求。

## ASS/SSA 字幕显示方框

中日文变成方框通常表示字幕渲染器未加载到包含相应字形的字体。元数据插件不负责渲染字幕；即使 ASS 能按 UTF-8 正常读取，缺少指定字体仍会出现此问题。

按 Jellyfin 的[官方字体配置指引](https://jellyfin.org/docs/general/administration/configuration#fonts)，网页 ASS 渲染使用服务器备用字体目录，字幕烧录使用服务器系统字体。可选择 Google 的 [Noto Sans SC](https://fonts.google.com/noto/specimen/Noto+Sans+SC)，直接使用 Noto 项目提供的完整 [NotoSansCJKsc-Regular.otf 下载链接](https://raw.githubusercontent.com/notofonts/noto-cjk/main/Sans/OTF/SimplifiedChinese/NotoSansCJKsc-Regular.otf)。它包含中文、日文和拉丁文字形；单个 Regular 文件约 15.7 MiB，专用备用字体目录只放这一份即可。更换字体会改变原来的字形外观，ASS 的时间、位置和特效仍保留。

**以下命令在 Jellyfin 所在的 Linux 服务器执行，不在开发电脑执行。** 字体直接从 Noto 官方项目下载，无需安装 Debian 的 Noto 字体包；若没有 `curl`、`fontconfig` 工具，请先安装这两个工具。

```bash
sudo install -d -m 755 /usr/local/share/fonts/jellyfin-noto
sudo curl --fail --location --retry 2 \
  https://raw.githubusercontent.com/notofonts/noto-cjk/main/Sans/OTF/SimplifiedChinese/NotoSansCJKsc-Regular.otf \
  --output /usr/local/share/fonts/jellyfin-noto/NotoSansCJKsc-Regular.otf
sudo chmod 644 /usr/local/share/fonts/jellyfin-noto/NotoSansCJKsc-Regular.otf
sudo fc-cache -f /usr/local/share/fonts/jellyfin-noto
```

1. 打开 **控制台 → 播放 → 转码**，将**备用字体文件路径**设为 `/usr/local/share/fonts/jellyfin-noto`，勾选**启用备用字体**并保存。容器部署须将目录挂载进去并填写容器内路径；服务端烧录还需容器内 fontconfig 能识别它。网页端列表支持 `.ttf`、`.otf`、`.woff`、`.woff2`，不列出 `.ttc` 和子目录中的字体。字体总量必须小于 20 MiB，达到上限的字体不会发送；因此不要将整套字体家族或中日文两个完整字体都放入此目录。需要减少下载体积时，Jellyfin 官方建议使用 WOFF2。
2. 先重新加载 Jellyfin 网页，再次播放并选择 ASS 字幕轨。若缺少原字体仍导致方框，请先保留原字幕副本，再将各样式的 `Fontname` 字段和行内 `\fn` 覆盖改为 `Noto Sans CJK SC`，注意填写字体族名而非字体文件名。以 UTF-8 保存并重新播放；这一份字体即可显示中日文两行字幕。仅在浏览器所在电脑安装字体，不能保证网页 ASS 渲染器可使用它。
3. 网页渲染仍有问题时，在用户的**字幕 → 烧录字幕**中选择**所有复杂格式字幕**，然后重新播放。上述命令也将字体安装到了 Linux 系统字体目录，供服务端烧录使用。检查新的 FFmpeg 日志是否使用字幕/ASS 滤镜，字体选择是否仍报缺字。烧录会触发视频转码，可能增加服务器负载。

若仍显示方框，检查浏览器对 `/FallbackFont/Fonts` 及各字体文件的请求；使用烧录时则检查 FFmpeg 字体选择日志，以区分缺少字体、路径或权限错误和字幕文件问题。

## 安装

在 Jellyfin 的 **插件 → 存储库 → 添加** 中，将名称设为 `VGMdb Concerts`，地址设为：

```text
https://wym3253.github.io/jellyfin-plugin-vgmdb-concerts-repository/repository.json
```

然后从 **目录** 安装 **VGMdb Concerts** 并重启 Jellyfin。若 GitHub Pages 不可用，可使用原始清单地址：

```text
https://raw.githubusercontent.com/wym3253/jellyfin-plugin-vgmdb-concerts-repository/main/repository.json
```

存储库地址保持不变；每次发布都会更新清单中对应的版本化 ZIP 下载链接和校验和。已发布的稳定版保留原版本化下载地址、校验和及 Jellyfin ABI，新版发布不会移除旧版回滚下载。每次发布都会通过公开网站验证清单内所有 ZIP 的下载和校验和。需要回滚时，先停止 Jellyfin，将此插件目录替换为所选兼容版本的发布包，再重新启动；已保存的元数据不会随之自动回滚。源码与发布文件见 [wym3253/jellyfin-plugin-vgmdb-concerts](https://github.com/wym3253/jellyfin-plugin-vgmdb-concerts/releases)。

## 开发

本插件基于 [jellyfin/jellyfin-plugin-vgmdb](https://github.com/jellyfin/jellyfin-plugin-vgmdb)。仓库保留上游音乐插件源码以便同步，但独立电影程序集不会编译这些音乐提供程序。编译、测试和发布打包仅使用手动触发的 GitHub Actions 工作流，不在本地编译或测试。
