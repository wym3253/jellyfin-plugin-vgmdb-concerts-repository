# Jellyfin VGMdb Concerts

[English](README.md) | [简体中文](README.zh-CN.md)

A Jellyfin 12.1 / .NET 10 Movie metadata and artwork plugin for Japanese concerts, Blu-rays, DVDs, and streaming archives. It can coexist with Jellyfin's official VGMdb music plugin; it does not register music album or artist providers.

## Source priority

1. Bangumi is always searched first for a concert event. A candidate must be a performance subject with a verified title and compatible year. A Day recording also requires the matching Bangumi episode. Searches include ordinary subtitles separated by quotes, dashes, or colons, without event-specific rules. A long partial title requires corroborating year evidence and a unique candidate; different same-language subtitles and tied best candidates are not silently accepted. Explicit recording dates and event-title years must match exactly. Folder release dates or unverified media years are weaker hints: the event may precede them by up to six years, but they cannot override an explicit event year or resolve ambiguity. If English and Japanese titles have no shared words, an optional Wikidata alias lookup retries Bangumi; Wikidata does not supply metadata or images. Existing subject IDs are validated before reuse.
2. Bangumi supplies the event title, original title, event date, description, tags, venue, external links, and primary cover. Day recordings remain separate playable Movies; their common collection identity follows the concert folder rather than a localized subject name. Disc titles retain their tour-leg names, and repeated Day numbers are distinguished by recording date or disc order.
3. When **Enable VGMdb** is on, VGMdb adds matching commercial-release metadata such as catalog, media format, studios, performers, release date tag, and release ID. Its cover is tried as a backup Primary image after all available Bangumi sizes fail. VGMdb is never allowed to replace a valid Bangumi event title, date, or cover.
4. If Bangumi has no verified result or is unreachable, a matching VGMdb concert-video release can still provide a fallback Movie result. If neither source matches, explicit Day archives and concert folders retain local fallback metadata. Ordinary movies are not claimed merely because they are in a concert-like path.

Bangumi's default placeholder and invalid artwork URLs are filtered. Its `large`, `common`, and `medium` image sizes are tried in order. Requests to both services use bounded concurrency, a bounded successful-response cache, cancellation propagation, and a short cooldown after transient failures. The upstream music plugin has been archived because `vgmdb.info` has closed. VGMdb supplementation requires a working compatible API configured in this plugin; its failure does not discard a valid Bangumi match or prevent Bangumi artwork retrieval.

The manual **Repair VGMdb Concerts collections and artwork** scheduled task handles only plugin-owned Movies and collections. It reuses matching Jellyfin collections, removes safely identified duplicate plugin collections, removes cast entries that are not concert performers, and saves preferred covers without invoking video-frame extraction itself. The task has no automatic trigger. After a plugin Movie's metadata download, that item's cast is cleaned and its cover is repaired. Jellyfin image-update notifications also restore a plugin Movie's missing cover without downloading its metadata again; a valid existing Primary image is preserved on this path. During library scans, affected Movies' cover requests wait until the scan finishes and recheck whether a missing cover still needs restoring. This does not start a full library repair. The manual task suppresses this per-item handler and invalidates older queued requests to avoid concurrent or stale saves. Explicit metadata refreshes and manual cover repair can replace a manually selected Primary image, and cast cleanup removes non-`Performer` people on plugin-owned Movies; other library items are untouched. Saves are only reported as successful after checking that a nonempty local image file exists, then Jellyfin is notified of the image change. When neither service offers a usable image, the plugin cannot manufacture a poster and Jellyfin may show a video frame.

## Options

The page at **Dashboard → Plugins → VGMdb Concerts** follows Jellyfin's interface language for English and Simplified Chinese; other languages use English. Bangumi-first source priority is fixed, not a switch.

| Option | Default | Effect |
| --- | --- | --- |
| Enable VGMdb | On | Enables VGMdb release supplements, fallback matching, and backup covers. Turn off to use Bangumi and local concert recognition without VGMdb API requests or cached VGMdb results. |
| Bangumi API / website address | `https://api.bgm.tv` / `https://bgm.tv` | API requests and subject links. |
| VGMdb API / website address | `https://vgmdb.info` / `https://vgmdb.net` | Supplementary release requests and links. |
| Request timeout | 15 seconds | Per network attempt; 1–300 seconds. |
| HTTP proxy | Empty | Optional proxy for this plugin. |
| Query cache | On | Coalesces concurrent requests and caches successful responses within a bounded process-local budget. |
| Cross-language title aliases | On | If Bangumi cannot verify an English title, request Japanese aliases from Wikidata and retry Bangumi. Can be disabled to avoid that external query. |
| AnitomySharp automatic title parsing | Off | Adds a parsed-title VGMdb query; explicit Day parsing remains independent. |
| Trust an existing official Bangumi ID | Off | Opt-in reuse only after subject type, title, year, and Day validation. |
| Local concert title mappings | Empty | Explicit folder-title-to-subject links for titles that cannot be matched automatically. See [Local concert title mappings](#local-concert-title-mappings) for syntax, examples, and how to update existing library items. |
| Concert companion fallback | On | Recognizes Day discs, other named discs, making-of footage, and bonus features, including unnumbered `SPECIAL DISC`, `Bonus01`, and `Menu01` files. Keeps each local disc or extra title when an event match is found; bonus features and menus use the event cover without requiring a Day episode. |
| Event archive fallback | On | Keeps unlisted Day archives and standalone events as local concert Movies. |

To avoid an unavailable VGMdb service, uncheck **Dashboard → Plugins → VGMdb Concerts → Enable VGMdb** and save. The change applies to subsequent lookups without restarting Jellyfin; requests already in flight may finish. Bangumi searches, Wikidata aliases, local title mappings, Day/extra recognition, and collection/artwork repair remain active. Saving the switch does not delete existing metadata, provider IDs, or image files. While disabled, new lookups cannot supply VGMdb-only release fields or backup covers, even if a VGMdb ID or cached response exists. Re-enable it after configuring a working compatible API to restore those optional features. AnitomySharp's additional VGMdb queries are also skipped while disabled.

Use a Movies library with one concert per folder. Keep explicit `Day 1` / `Day 2` and `Archive` / `アーカイブ` markers in archive filenames. After upgrading, finish a library scan, then run **Dashboard → Scheduled Tasks → VGMdb Concerts → Repair VGMdb Concerts collections and artwork** once to correct existing cast and retry Movie covers. Run it again only when collection membership or artwork needs repair; ordinary scans do not run the full task. A full metadata refresh on an individual item still repairs that item's cover. Check access to `api.bgm.tv` and `lain.bgm.tv` if a cover is still missing. Jellyfin's "replace existing trickplay images" option affects playback previews, not posters; enabling it may cause separate video-processing work. If NFO or image writes report permission errors, disable saving metadata alongside media or grant Jellyfin write access to those folders.

If a previously saved cover disappears, check that Jellyfin's metadata directory is writable and persists across restarts, and that no external cleanup removes its image files. A collection cover and its member Movies' covers are separate files. The successful-save log includes each item's actual image path. Missing-image notifications trigger a targeted restore; files removed while Jellyfin is idle need a library scan or the manual repair task before they can be detected.

## Local concert title mappings

Use a mapping when a romanized or translated concert folder title cannot be verified through Bangumi or Wikidata and you already know the correct Bangumi performance subject. No event mappings are bundled with the plugin.

1. Open **Dashboard → Plugins → VGMdb Concerts → Local concert title mappings**.
2. Enter one mapping per line, using `cleaned concert folder title = Bangumi subject URL or ID`. Use the concert folder name from the media path, rather than Jellyfin's translated display title or an individual video's filename. For example, `[Release] City Orchestra Winter LIVE [BDRip 1080p]` becomes `City Orchestra Winter LIVE`. Remove release-group and media-format tags, but retain punctuation and subtitles that belong to the concert title. Do not add file-level `Day 1`, `Bonus01`, or `Menu01` suffixes.
3. Click **Save**. Mapping changes apply to subsequent metadata requests without restarting Jellyfin. Installing a new plugin version still requires a restart.
4. To update existing library items, wait for the library scan to finish, then run **Dashboard → Scheduled Tasks → VGMdb Concerts → Repair VGMdb Concerts collections and artwork** once. It refreshes Movies with a new or changed mapped subject, fixes numbered-extra identities, updates collection members, and refreshes affected collections' metadata and covers. New items use the mapping during their normal metadata lookup.

Example configuration, with two independent concerts and both accepted target formats:

```text
City Orchestra Winter LIVE = https://bangumi.tv/subject/12345
Harbor Ensemble Summer Concert = 67890
```

The titles and IDs above are placeholders; replace them with your own folder titles and verified subjects. Enter plain lines without JSON, quotation marks, or Markdown code fences. One line covers all Days, extras, and the collection for that concert folder; do not duplicate it for each file.

Matching ignores letter case, Unicode width, and repeated whitespace, but otherwise requires the entire cleaned folder title to match. The right side accepts a positive numeric subject ID or an HTTP/HTTPS `/subject/<id>` link on `bangumi.tv`, `bgm.tv`, or `chii.in`; an episode (`/ep/`) link is not a subject link. Different folder titles can point to the same subject. Conflicting IDs for the same normalized title are rejected; assigning that title several IDs cannot distinguish different tour legs.

A mapping replaces only title-similarity validation. The subject must still be a compatible performance with a compatible year, and Day recordings must have the required episodes. Extras and menus use the event cover without requiring a Day episode. If it does not apply, check the actual folder title, target subject, year, and Day numbering. Logs report invalid/conflicting mappings or incompatible events; an invalid mapping is not replaced by trusting an old stored ID.

### Avoiding unnecessary work

- Keep **Query cache** enabled. Successful subject and episode-page responses are shared across files, and concurrent duplicate requests are coalesced. The cache is process-local, so restarting Jellyfin discards it.
- A valid mapping directly retrieves the subject, bypassing Bangumi title searches and Wikidata alias lookup. It still retrieves and validates subject/episode data and, if enabled, tries VGMdb supplementation; it is not an offline metadata cache.
- Run the manual repair after applying or changing mappings to existing items, then only when collections or artwork need repair. An unchanged mapped subject does not by itself force another full Movie metadata refresh. For an isolated Movie issue, prefer refreshing that item; the full task remains necessary for collection repairs. Replacing trickplay images is unrelated to applying mappings or restoring posters.
- Turn off **Enable VGMdb** when you do not need release supplementation or have no working compatible API. This avoids waiting for the closed default `vgmdb.info` service while preserving Bangumi metadata and covers. Leaving the API address blank alone uses the default address. When VGMdb is enabled, **Request timeout** applies to each attempt, with up to three attempts for transient failures; it is not a limit on the entire repair task and also affects Bangumi and artwork. With query caching enabled, a service cooldown avoids new requests after a transient failure; repeated cooldown warnings do not mean another network request was sent.

## ASS/SSA subtitles displayed as boxes

Boxes in place of Chinese or Japanese text usually mean that the subtitle renderer cannot load fonts containing those glyphs. The metadata plugin does not render subtitles. A readable UTF-8 ASS file can still have this problem when its named fonts are unavailable.

Following Jellyfin's [font configuration guide](https://jellyfin.org/docs/general/administration/configuration#fonts), use a server fallback-font directory for Web ASS rendering and server system fonts for subtitle burning. A simple choice is Google's [Noto Sans SC](https://fonts.google.com/noto/specimen/Noto+Sans+SC), using the Noto project's complete [NotoSansCJKsc-Regular.otf download](https://raw.githubusercontent.com/notofonts/noto-cjk/main/Sans/OTF/SimplifiedChinese/NotoSansCJKsc-Regular.otf). This font covers Chinese, Japanese, and Latin text. The single Regular file is about 15.7 MiB; keep only this font in the dedicated fallback directory. It changes the original typeface but retains the ASS timing, positioning, and effects.

**Run these commands on the Jellyfin Linux server, not on the development computer.** They download the font directly from the official Noto project; no Debian Noto font package is needed. Install `curl` and `fontconfig` first if these tools are unavailable.

```bash
sudo install -d -m 755 /usr/local/share/fonts/jellyfin-noto
sudo curl --fail --location --retry 2 \
  https://raw.githubusercontent.com/notofonts/noto-cjk/main/Sans/OTF/SimplifiedChinese/NotoSansCJKsc-Regular.otf \
  --output /usr/local/share/fonts/jellyfin-noto/NotoSansCJKsc-Regular.otf
sudo chmod 644 /usr/local/share/fonts/jellyfin-noto/NotoSansCJKsc-Regular.otf
sudo fc-cache -f /usr/local/share/fonts/jellyfin-noto
```

1. In **Dashboard → Playback → Transcoding**, set **Fallback font folder path** to `/usr/local/share/fonts/jellyfin-noto` and enable **Enable fallback fonts**, then save. For containers, mount the directory inside the Jellyfin container and use that container-visible path; for server-side burning, fontconfig must also see it inside the container. The Web list supports `.ttf`, `.otf`, `.woff`, and `.woff2`, without listing `.ttc` files or nested directories. Its combined font size must remain below 20 MiB; fonts reaching the limit are omitted. Avoid downloading an entire font family or adding both full Chinese and Japanese font files to this directory. Jellyfin recommends WOFF2 when reducing download size is necessary.
2. First reload Jellyfin Web and restart playback with the ASS track selected. If a missing original font still produces boxes, keep an original subtitle copy and change its styles' `Fontname` fields and any inline `\fn` overrides to `Noto Sans CJK SC` (the font family name, not the filename). Save as UTF-8 and restart playback. This single font can render both the Chinese and Japanese subtitle lines. Installing a font only on the browser computer does not ensure that the Web ASS renderer can use it.
3. If Web rendering still fails, choose **Subtitles → Burn subtitles → All complex formats** in the user's subtitle settings, then restart playback. The commands above also install the font in a Linux system font directory for burning. Confirm in the new FFmpeg log that a subtitle/ASS filter is used and that font selection has no missing-glyph errors. Burning requires video transcoding and can increase server load.

If boxes remain, inspect browser network requests to `/FallbackFont/Fonts` and its font downloads, or the FFmpeg font-selection log when burning. Those distinguish a missing font/path or access failure from a subtitle-file problem.

## Install

In Jellyfin, open **Plugins → Repositories → Add**, name the repository `VGMdb Concerts`, and use:

```text
https://wym3253.github.io/jellyfin-plugin-vgmdb-concerts-repository/repository.json
```

Then install **VGMdb Concerts** from **Catalog** and restart Jellyfin. If GitHub Pages is unavailable, the raw manifest is at:

```text
https://raw.githubusercontent.com/wym3253/jellyfin-plugin-vgmdb-concerts-repository/main/repository.json
```

The repository URL stays stable. Each release updates the manifest's exact versioned ZIP download link and checksum. Published stable packages remain downloadable at their original versioned URLs, with their original checksum and Jellyfin ABI, so a new release does not remove rollback downloads. Each publication verifies every catalog ZIP and checksum through the public site. To roll back, stop Jellyfin, replace this plugin's directory with the chosen compatible release package, and restart; saved metadata is not rolled back automatically. The source and release assets are at [wym3253/jellyfin-plugin-vgmdb-concerts](https://github.com/wym3253/jellyfin-plugin-vgmdb-concerts/releases).

## Development

The plugin is based on [jellyfin/jellyfin-plugin-vgmdb](https://github.com/jellyfin/jellyfin-plugin-vgmdb). The upstream music sources remain in the repository for synchronization but are excluded from this standalone Movie assembly. Run builds, tests, and release packaging only through the manually triggered GitHub Actions workflows; do not build or test locally.
