# Jellyfin VGMdb Concerts

A standalone Jellyfin 10.11 metadata provider for Japanese concert Blu-rays and DVDs catalogued by VGMdb.

`VGMdb Concerts` has its own plugin GUID, assembly, provider name, and Movie external ID. It can be installed alongside Jellyfin's official `VGMdb` music plugin. This plugin does not register Artist or MusicAlbum providers.

## Concert movie features

- Searches VGMdb albums from a Jellyfin **Movies** library.
- Filters automatic matches to releases carrying both live and video signals.
- Maps title, original Japanese title, release date, overview, genres, studios, catalog number, media format, and publish format.
- Maps VGMdb performers to Jellyfin people so a performer can link multiple concerts.
- Provides the primary cover and a clickable VGMdb Movie external ID.
- Prefers Japanese names when the library metadata language is `ja`; otherwise prefers romanized and English names.
- Supports an exact folder/file hint such as `[vgmdbid-116768]`.
- Ranks catalog-number matches first, followed by exact title, year, and partial title matches.
- Fuzzy-ranks remaining results by the best Levenshtein similarity across Japanese, romanized, English, and fallback titles.
- Optionally uses AnitomySharp to derive an additional query from automatic Movie file names. It is disabled by default,
  never parses manual searches or explicit VGMdb IDs, retains the original query, merges duplicate VGMdb releases, and
  confidence-penalizes parsed-title matches before applying the existing ranking rules.

VGMdb describes the commercial video release, not necessarily the original performance date or venue. Those event-level fields remain suitable for a future LiveFans/local-NFO integration.

## Recommended Jellyfin layout

Create a Movies library and keep one concert release per folder:

```text
Concerts/
└── THE IDOLM@STER SHINY COLORS 3rdLIVE TOUR NAGOYA (2022) [vgmdbid-116768]/
    └── THE IDOLM@STER SHINY COLORS 3rdLIVE TOUR NAGOYA (2022) [vgmdbid-116768].mkv
```

Set the library's preferred metadata language to Japanese if Japanese titles and performer names should be used. In the library metadata provider settings, enable and order **VGMdb Concerts** as desired.

The optional AnitomySharp parser can be enabled under **Dashboard → Plugins → VGMdb Concerts**. It is most useful for
file names containing release groups, resolutions, codecs, and source tags. Keep it disabled when concert titles contain
unusual numbering that should be passed to VGMdb unchanged.

## Install

The recommended installation method follows Jellyfin's plugin-repository workflow and uses GitHub only:

1. In the Jellyfin dashboard, open **Plugins → Repositories** and select **Add**.
2. Set the repository name to `VGMdb Concerts`.
3. Set the repository URL to:

   ```text
   https://raw.githubusercontent.com/wym3253/jellyfin-plugin-vgmdb-concerts-repository/main/repository.json
   ```

4. Save, open **Catalog**, find **VGMdb Concerts**, and install it.
5. Restart Jellyfin after installation or update.

Installing through the catalog allows Jellyfin to discover later releases published by this repository. The private source repository publishes only the catalog manifest and compiled ZIP files to a dedicated public GitHub repository; no Cloudflare, GitHub Pages, or third-party mirror is used.

## Build and test

The plugin targets .NET 9 and Jellyfin 10.11. GitHub Actions performs the authoritative build on every push and pull request:

1. Open the repository's **Actions** page.
2. Select the latest successful **Build and test** run.
3. Download the `Jellyfin.Plugin.Vgmdb-Concerts-*` artifact.
4. Copy `Jellyfin.Plugin.VgmdbConcerts.dll` into a dedicated directory below Jellyfin's plugins directory and restart Jellyfin.

The workflow restores dependencies, runs the complete test project in Release mode, publishes the plugin, and retains the downloadable artifact for 30 days. It can also be started manually with **Run workflow**.

## Data source note

The plugin uses the community-operated `vgmdb.info` JSON API, because VGMdb does not publish an official API. Service availability and upstream schema changes are outside this plugin's control.

## Upstream and license

Based on [jellyfin/jellyfin-plugin-vgmdb](https://github.com/jellyfin/jellyfin-plugin-vgmdb). The complete upstream runtime source is retained so upstream can be fetched and merged normally. The project file excludes upstream Artist/MusicAlbum discovery types and the upstream plugin entry point from this standalone assembly; consequently, the built DLL registers only Movie metadata, image, external-ID, and external-URL providers.

The `upstream` remote is fetch-only. To synchronize it:

```powershell
git fetch upstream master
git merge upstream/master
```

The **Sync upstream** GitHub Actions workflow also checks for upstream changes every day at 00:17 JST and can be started manually. It merges `upstream/master`, increments the standalone patch version, restores dependencies, and runs the complete test suite before pushing to this repository's `master` branch. When there is no upstream update it creates no commit; merge conflicts or failed tests stop the workflow without pushing.

Releases use the repository's `VERSION` file and independent tags such as `concerts-v1.0.0`, avoiding collisions with tags inherited from upstream. Each successful upstream merge publishes the next patch version as a GitHub Release with a versioned ZIP package. A rerun also repairs a missing Release for the current version without creating another source commit. The workflow refuses to publish if `VERSION`, the assembly version, and `build.yaml` disagree.

After a merge, the tests inspect the compiled assembly's discovery surface and fail if an upstream Artist/MusicAlbum provider becomes registered. The standalone plugin name, assembly name, GUID, and Movie external-ID key remain independent of the official plugin.

Licensed under GPL-3.0.
