# Third-party notices

## AnitomySharp.NET6 0.5.1

VGMdb Concerts distributes the unmodified `AnitomySharp.dll` library for optional automatic file-name parsing.

- Project and source: https://github.com/chu-shen/AnitomySharp/tree/v0.5.1
- License: Mozilla Public License 2.0
- License text: https://github.com/chu-shen/AnitomySharp/blob/v0.5.1/LICENSE

AnitomySharp remains separately licensed under the MPL-2.0. The VGMdb Concerts setting only controls whether
the library is called at runtime; the dependency is included in every plugin package.
