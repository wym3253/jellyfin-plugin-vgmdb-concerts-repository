# Jellyfin VGMdb Concerts

[English](README.md) | [简体中文](README.zh-CN.md)

A Jellyfin 12.1 / .NET 10 Movie metadata and artwork plugin for Japanese concerts, Blu-rays, DVDs, and streaming archives. It can coexist with Jellyfin's official VGMdb music plugin; it does not register music album or artist providers.

## Source priority

1. Bangumi is always searched first for a concert event. A candidate must be a performance subject with a verified title and compatible year. A Day recording also requires the matching Bangumi episode. Distinctive partial titles are accepted only with a matching year and a unique candidate. If English and Japanese titles have no shared words, an optional Wikidata alias lookup retries Bangumi; Wikidata does not supply metadata or images. Existing subject IDs are validated before reuse.
2. Bangumi supplies the event title, original title, event date, description, tags, venue, external links, and primary cover. Day recordings remain separate playable Movies; their common collection identity follows the concert folder rather than a localized subject name. Disc titles retain their tour-leg names, and repeated Day numbers are distinguished by recording date or disc order.
3. VGMdb adds matching commercial-release metadata such as catalog, media format, studios, performers, release date tag, and release ID. Its cover is tried as a backup Primary image after all available Bangumi sizes fail. VGMdb is never allowed to replace a valid Bangumi event title, date, or cover.
4. If Bangumi has no verified result or is unreachable, a matching VGMdb concert-video release can still provide a fallback Movie result. If neither source matches, explicit Day archives and concert folders retain local fallback metadata. Ordinary movies are not claimed merely because they are in a concert-like path.

Bangumi's default placeholder and invalid artwork URLs are filtered. Its `large`, `common`, and `medium` image sizes are tried in order. Requests to both services use bounded concurrency, a bounded successful-response cache, cancellation propagation, and a short cooldown after transient failures. VGMdb is a community-run JSON API and may be unreachable on some networks; its failure does not discard a valid Bangumi match.

The post-scan repair handles only plugin-owned Movies and collections. It refreshes their metadata and saves the preferred cover directly, without invoking video-frame extraction itself. A manual full metadata refresh also repairs the cover after Jellyfin finishes its own image refresh. This can replace a manually selected Primary image on a plugin-owned item; local artwork outside those items is untouched. When neither service offers a usable image, the plugin cannot manufacture a poster and Jellyfin may show a video frame.

## Options

The page at **Dashboard → Plugins → VGMdb Concerts** follows Jellyfin's interface language for English and Simplified Chinese; other languages use English. Bangumi-first source priority is fixed, not a switch.

| Option | Default | Effect |
| --- | --- | --- |
| Bangumi API / website address | `https://api.bgm.tv` / `https://bgm.tv` | API requests and subject links. |
| VGMdb API / website address | `https://vgmdb.info` / `https://vgmdb.net` | Supplementary release requests and links. |
| Request timeout | 15 seconds | Per network attempt; 1–300 seconds. |
| HTTP proxy | Empty | Optional proxy for this plugin. |
| Query cache | On | Coalesces concurrent requests and caches successful responses within a bounded process-local budget. |
| Cross-language title aliases | On | If Bangumi cannot verify an English title, request Japanese aliases from Wikidata and retry Bangumi. Can be disabled to avoid that external query. |
| AnitomySharp automatic title parsing | Off | Adds a parsed-title VGMdb query; explicit Day parsing remains independent. |
| Trust an existing official Bangumi ID | Off | Opt-in reuse only after subject type, title, year, and Day validation. |
| Concert companion fallback | On | Recognizes Day discs, other named discs, making-of footage, and bonus features. Keeps each local disc title when an event match is found. |
| Event archive fallback | On | Keeps unlisted Day archives and standalone events as local concert Movies. |

Use a Movies library with one concert per folder. Keep explicit `Day 1` / `Day 2` and `Archive` / `アーカイブ` markers in archive filenames. After upgrading, scan the library once to repair existing items, or run a full metadata refresh on an individual item. Check access to `api.bgm.tv` and `lain.bgm.tv` if a cover is still missing. Jellyfin's "replace existing trickplay images" option affects playback previews, not posters; enabling it may cause separate video-processing work. If NFO or image writes report permission errors, disable saving metadata alongside media or grant Jellyfin write access to those folders.

## Install

In Jellyfin, open **Plugins → Repositories → Add**, name the repository `VGMdb Concerts`, and use:

```text
https://wym3253.github.io/jellyfin-plugin-vgmdb-concerts-repository/repository.json
```

Then install **VGMdb Concerts** from **Catalog** and restart Jellyfin. If GitHub Pages is unavailable, the raw manifest is at:

```text
https://raw.githubusercontent.com/wym3253/jellyfin-plugin-vgmdb-concerts-repository/main/repository.json
```

The repository URL stays stable. Each release updates the manifest's exact versioned ZIP download link and checksum. The source and release assets are at [wym3253/jellyfin-plugin-vgmdb-concerts](https://github.com/wym3253/jellyfin-plugin-vgmdb-concerts).

## Development

The plugin is based on [jellyfin/jellyfin-plugin-vgmdb](https://github.com/jellyfin/jellyfin-plugin-vgmdb). The upstream music sources remain in the repository for synchronization but are excluded from this standalone Movie assembly. Build and test with a local .NET 10 SDK container; no GitHub Actions are required for a release.
