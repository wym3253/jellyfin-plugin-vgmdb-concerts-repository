# Jellyfin VGMdb Concerts

[English](README.md) | [简体中文](README.zh-CN.md)

A standalone Jellyfin 12.1 metadata provider for Japanese concert Blu-rays, DVDs, and event archives catalogued by VGMdb or Bangumi.

`VGMdb Concerts` has its own plugin GUID, assembly, provider name, and Movie external ID. It can be installed alongside Jellyfin's official `VGMdb` music plugin. This plugin does not register Artist or MusicAlbum providers.

## Concert movie features

- Searches VGMdb albums from a Jellyfin **Movies** library.
- Filters automatic matches to releases carrying both live and video signals.
- Maps title, original Japanese title, release date, overview, genres, studios, catalog number, media format, and publish format.
- Maps VGMdb performers to Jellyfin people so a performer can link multiple concerts.
- Provides the primary cover and a clickable VGMdb Movie external ID.
- Prefers Japanese names when the library metadata language is `ja`; otherwise prefers romanized and English names.
- Supports an exact folder/file hint such as `[vgmdbid-116768]`.
- Ranks catalog-number matches first, followed by exact title, year, and partial title matches.
- Fuzzy-ranks remaining results by the best Levenshtein similarity across Japanese, romanized, English, and fallback titles.
- Optionally uses AnitomySharp to derive an additional query from automatic Movie file names. It is disabled by default,
  never parses manual searches or explicit VGMdb IDs, retains the display title, original title, and verified concert
  parent-folder queries, merges duplicate releases, and confidence-penalizes parsed-title matches before applying the
  existing ranking rules. Separator-dash variants improve recall without changing word-internal hyphens such as `Blu-ray`.
- Caches successful VGMdb and Bangumi searches/details in a bounded in-memory cache by default. Concurrent identical
  requests are coalesced, successful entries expire after at most seven days with a six-hour sliding window, and failed
  responses are never cached. A transient service failure starts a two-minute cooldown so a library scan does not repeat
  the same unreachable-host request for every file.
- Supplements successful VGMdb matches from high-confidence Bangumi event subjects by default. VGMdb remains authoritative
  for commercial release identity, title, date, catalog data, format, and primary cover. Bangumi may add an event summary,
  event date tag, venue, tags, collection name for an identified Day, IDs, links, and landscape artwork. Any Bangumi
  network, JSON, timeout, or confidence failure leaves the complete VGMdb result unchanged.
- Falls back by default for unlisted event recordings, including multi-day streaming archives and standalone concert
  folders. It runs only after VGMdb
  returns no eligible concert video, or VGMdb is unavailable, for a Movie title containing both an explicit Day number
  and an Archive/アーカイブ marker. Automatic scans and metadata refreshes may use this fallback, while manual Identify
  searches remain unparsed. If another provider has already normalized the displayed title and removed those markers,
  automatic refreshes recover them from the source filename. It preserves separate day movies, assigns a shared Jellyfin
  collection name, and never invents a VGMdb ID or commercial-release metadata.
- Recognizes local concert companion files during automatic scans and metadata refreshes by default, without changing
  manual Identify searches. Normal Day discs still prefer an eligible VGMdb release; Making of, backstage, メイキング,
  舞台裏, 幕后, and 花絮 files are classified as `BehindTheScenes`, while numbered discs carrying an explicit bonus,
  documentary, vacation, or 特典 signal are classified as `Featurette`. These items retain their own playable Movie
  entries and inherit the cleaned concert-folder collection identity.
- Optionally enriches local concert fallback metadata from Bangumi event subjects. This switch is disabled by default and
  applies directly to Day companion items when companion recognition is enabled; archive-marked Day items and standalone
  concert folders additionally require the event archive fallback. Only high-confidence type `演出` matches with a
  compatible year and the required episode coverage are accepted.
  Standalone events retain a single Movie identity and do not receive an invented Day suffix or collection. Bangumi can supply the
  event date, summary, per-day performer and setlist text, venue, landscape artwork, tags, subject/episode IDs, and external links.
  Network, JSON, or confidence failures preserve the pure local archive fallback instead of failing metadata refresh.
- Provides TMDb-style metadata for generated concert `BoxSet` items. It accepts only collections with members identified
  by VGMdb Concerts, writes an independent stable collection ID, and aggregates the collection title, overview, first
  event date, year, genres, studios, and collection tags from those members.

VGMdb describes the commercial video release, not necessarily the original performance date or venue. Those event-level fields remain suitable for a future LiveFans/local-NFO integration.

## Plugin options

The configuration page is under **Dashboard → Plugins → VGMdb Concerts**. It follows Jellyfin's display language for
English and Simplified Chinese and falls back to English for other languages.

| Option | Default | Purpose |
| --- | --- | --- |
| VGMdb API address | `https://vgmdb.info` | Base address of the VGMdb-compatible JSON API. |
| VGMdb website address | `https://vgmdb.net` | Base address used for clickable VGMdb release links. |
| Bangumi API address | `https://api.bgm.tv` | Base address of the Bangumi v0 API. |
| Bangumi website address | `https://bgm.tv` | Base address used for clickable Bangumi subject links. |
| Request timeout in seconds | `15` | Per-attempt timeout, constrained to 1-300 seconds. |
| HTTP proxy address | Empty | Optional HTTP or HTTPS proxy used only by this plugin. |
| Cache successful VGMdb and Bangumi queries | On | Coalesces identical in-flight requests and caches successful responses within a 64 MiB process-local budget. Turning it off also disables failure cooldowns. |
| Use AnitomySharp for automatic file-name searches | Off | Adds a parsed-title query for automatic searches without changing manual searches or explicit VGMdb IDs. |
| Use Bangumi to supplement successful VGMdb matches | On | Adds validated event metadata while leaving commercial release fields authoritative in VGMdb. |
| Trust an existing ID from the official Bangumi plugin | Off | Reuses that ID only after event type, title, year, and required Day coverage validation. |
| Recognize concert discs, making-of videos, and bonus features | On | Identifies companion files from a verified concert context while retaining separate playable Movies. |
| Group unlisted multi-day concert archives into collections | On | Applies the local archive/event fallback only after no eligible VGMdb result is found. |
| Use Bangumi to enrich local concert fallback metadata | Off | Enriches ordinary Day companions directly; archive-marked Day items and standalone events also require event fallback. |

## Recommended Jellyfin layout

Create a Movies library and keep one concert release per folder:

```text
Concerts/
└── THE IDOLM@STER SHINY COLORS 3rdLIVE TOUR NAGOYA (2022) [vgmdbid-116768]/
    └── THE IDOLM@STER SHINY COLORS 3rdLIVE TOUR NAGOYA (2022) [vgmdbid-116768].mkv
```

Set the library's preferred metadata language to Japanese if Japanese titles and performer names should be used. In the library metadata provider settings, enable and order **VGMdb Concerts** as desired.

The optional AnitomySharp parser can be enabled under **Dashboard → Plugins → VGMdb Concerts**. It is most useful for
file names containing release groups, resolutions, codecs, and source tags. It supplies an additional title only: the
plugin's explicit `Day` parser remains authoritative because anime episode numbers are not reliable concert-day numbers.
Keep AnitomySharp disabled when concert titles contain unusual numbering that should be sent to VGMdb unchanged.

The configuration page exposes service addresses, timeout, proxy, and official-ID trust alongside all other options.
Every option has English and Simplified Chinese text. The page follows Jellyfin's current display language automatically
and falls back to English for other languages.

The event archive fallback is enabled by default on the same plugin page. For example, these automatic Movie titles are kept
as separate items and assigned the shared collection `THE IDOLM@STER SHINY COLORS LIVE FUN!! -Beyond the Blue sky-`:

```text
THE IDOLM@STER SHINY COLORS LIVE FUN!! -Beyond the Blue sky- Day 1 (アーカイブ)
THE IDOLM@STER SHINY COLORS LIVE FUN!! -Beyond the Blue sky- Day 2 (アーカイブ)
如月千早武道館単独公演「OathONE」 Day 1（アーカイブ）
```

The same fallback applies to a standalone concert folder when no VGMdb concert-video release matches. For
example, `Ave Mujica 0th LIVE「Primo die in scaena」` can be matched to a high-confidence Bangumi `演出`
subject and receive its localized title, original title, date, overview, tags, IDs, link, and artwork. Matching remains
generic: no artist, concert title, or Bangumi subject ID is embedded in production code. Release-group and technical
brackets are removed before matching, and a Bangumi/network/confidence failure keeps the cleaned local concert metadata.
Existing standalone Movies receive one full metadata refresh when this identity is first adopted, even if they already
have artwork; later scans do not repeatedly overwrite user metadata.

The plugin deliberately does not install a second filesystem watcher. Jellyfin's library **Enable real time monitoring**
option watches supported folders and starts the incremental library scan; VGMdb Concerts participates as a Movie provider,
then runs its collection/identity repair after the scan. This avoids duplicate watchers and duplicate scans. For network
shares or filesystems whose change notifications are unavailable, keep Jellyfin's scheduled library scan enabled.

The plugin does not trust a numeric `Bangumi` ID written by the official Bangumi plugin unless the opt-in option is
enabled. Even when enabled, the subject is reused only after compatibility validation. When collection members still
have no remote image identity, the collection image provider performs its own Bangumi event search using the canonical
collection title and year, with the same event-type and title-confidence checks used for metadata. This is generic
collection behavior; no artist, tour, quadrant, or subject ID is embedded in production code.

Bangumi infobox parsing accepts both scalar and structured-array values. Generic Day companion items use the same
optional Bangumi enrichment and confidence checks as archive files. VGMdb Concerts has first priority for its managed
Movie artwork.

The parser recognizes generic festival markers such as `FES`, `フェス`, and `歌合戦`, recovers the event year from dated
release folders, and accepts Day markers before stream variants such as `DAY1 SW` or `DAY1 定点`. Release-group
and codec tags no longer leak into Movie titles. The post-scan repair also restores per-leg titles (for example,
`Brilliant Blooms Day 1`) when an album-level VGMdb match previously gave every disc the same release title.

The nearest concert parent folder is the stable collection identity. Bangumi supplementation may localize individual
Movie titles, but it does not replace that identity or create a second collection. For example,
`シャイニーカラーズ8th Day 1（アーカイブ）` below
`[260425-26] THE IDOLM@STER SHINY COLORS ∞th LIVE iと夢 (ASOBI)` is grouped under the cleaned canonical collection
`THE IDOLM@STER SHINY COLORS ∞th LIVE iと夢`. More specific file titles such as `Brilliant Blooms Day 1` remain the
individual Movie titles, while all discs and making-of items below the same release folder share one collection.
Automatic VGMdb matching also queries this stable parent release in addition to the specific file title.

The companion fallback is enabled by default on the same configuration page. It walks through intermediate `Disc N`
folders to find the nearest concert root, so `Disc 3/Making of ... Day 1.mkv` is marked Behind the Scenes and
`Disc 7 - Shinymas's Summer Vacation in Okinawa.mkv` is marked Featurette. Explicit VGMdb IDs remain authoritative.
For items previously identified incorrectly by another provider, refresh with **Replace all metadata** once so stale
provider IDs do not keep that old manual identification.

After at least two movies with the same generated collection identity have completed metadata refresh, run a subsequent
full library scan. The plugin's post-scan task creates and reconciles the collection directly, so Jellyfin's
**Automatically add to collections** option is not required for this plugin-managed grouping. An individual
**Refresh metadata** operation writes `CollectionName` but does not run post-scan tasks, so refresh both Day items and
then run **Scan All Libraries** once. Day files remain separate playable Movies inside the generated collection rather
than being treated as alternate versions of one Movie. Equal display names from different source folders use separate
on-disk collection paths and do not merge across libraries.
After each full scan, the plugin reconciles identified concert Movies against that stable folder identity. It moves
members out of obsolete plugin-generated per-file collections without deleting collection items, and
clears local image database entries whose referenced files no longer exist before asking Jellyfin to refresh them.

The separate Bangumi enrichment checkbox uses Bangumi only inside this archive fallback. It does not replace VGMdb for
commercial Blu-ray/DVD releases. The original event title and a punctuation-simplified additional query are both sent,
then their candidates are merged by subject ID. Results remain constrained to event subjects and are ranked locally by
normalized title, year, and episode coverage before the selected Day is fetched. The plugin sends the identifiable,
versioned User-Agent required by the Bangumi API. If Bangumi is unavailable or neither query passes the confidence checks,
the same movies still receive the local title, year, genres, tags, and collection name from the archive fallback. Movies
previously identified by the pure local fallback are enriched in place on their next metadata refresh; deleting metadata
or re-importing files is not required.

The query cache follows the successful-response cache used by the Bangumi Jellyfin plugin, while adding in-flight
request coalescing and a short transient-service failure cooldown. It is process-local, has an estimated 64 MiB capacity, is cleared
on Jellyfin restart, and can be disabled under **Dashboard → Plugins → VGMdb Concerts**. Disabling it also disables the
cooldown.

Jellyfin marks an interactive **Refresh metadata** request as non-automated; the plugin handles that refresh path
explicitly without exposing parsed archive fallback entries in the manual **Identify** search result list. It also reads
the source filename during that refresh when the stored display title no longer contains `Day` and `アーカイブ`; this is
required after another metadata provider has renamed an item. A `生放送` file does not
qualify for the archive fallback and remains an independent Movie.

Image selection is slot-aware: a VGMdb release cover is preferred for Primary while a distinct Bangumi event image is
used for Backdrop. Invalid URLs and Bangumi's default placeholder are discarded, HTTP URLs on known image hosts are
upgraded to HTTPS, and one URL is never repeated across multiple remote-image slots. Local `poster`, `landscape`, and
`backdrop` files still take precedence over remote providers.

Automatically created collections are separate `BoxSet` items and do not inherit their movies' metadata or artwork.
Following Jellyfin's TMDb BoxSet design, VGMdb Concerts first identifies and populates a narrowly scoped concert
collection, then resolves its images. Remote VGMdb/Bangumi artwork remains preferred. If those sources have no usable
image, a dynamic fallback reuses the first already-downloaded local image from an identified member Movie. Primary,
Backdrop, and Thumb remain supported by that local fallback without duplicating one remote URL across slots. Refresh the collection's metadata and images once
after updating the plugin.

## Install

The recommended installation method follows Jellyfin's plugin-repository workflow and uses GitHub only:

1. In the Jellyfin dashboard, open **Plugins → Repositories** and select **Add**.
2. Set the repository name to `VGMdb Concerts`.
3. Set the repository URL to:

   ```text
   https://wym3253.github.io/jellyfin-plugin-vgmdb-concerts-repository/repository.json
   ```

4. Save, open **Catalog**, find **VGMdb Concerts**, and install it.
5. Restart Jellyfin after installation or update.

Installing through the catalog allows Jellyfin to discover later releases. Every release updates the dedicated public
repository manifest and its exact versioned ZIP URL before the release is considered complete. If GitHub Pages is
unavailable in a particular network, the raw GitHub URL remains a fallback:

```text
https://raw.githubusercontent.com/wym3253/jellyfin-plugin-vgmdb-concerts-repository/main/repository.json
```

The repository URL is stable and does not change between releases. Its `repository.json`, checksum, and exact versioned
download URL are regenerated for every release, so Jellyfin discovers later versions through the same install URL.

## Build and test

The plugin targets .NET 10 and Jellyfin 12.1. Restore, build, tests, vulnerability audit, publish, and Jellyfin loading can
all be run in disposable local Docker containers. Release ZIP files are available from the plugin catalog and the
corresponding GitHub Release; place the extracted plugin files in a dedicated Jellyfin plugin directory and restart the
server.

## Data source note

The plugin uses the community-operated `vgmdb.info` JSON API, because VGMdb does not publish an official API. Optional
event archive enrichment uses the official anonymous [Bangumi API](https://bangumi.github.io/api/) with project
attribution in its User-Agent. Service availability, user-contributed metadata, image hosting, and upstream schema
changes are outside this plugin's control.

## Upstream and license

Based on [jellyfin/jellyfin-plugin-vgmdb](https://github.com/jellyfin/jellyfin-plugin-vgmdb). The complete upstream runtime source is retained so upstream can be fetched and merged normally. The project file excludes upstream Artist/MusicAlbum discovery types and the upstream plugin entry point from this standalone assembly. The built DLL registers Movie metadata, image, external-ID, and external-URL providers, metadata and image providers restricted to BoxSets generated from identified concert Movies, and a post-scan repair limited to those identified Movies and managed BoxSets; it does not register any Artist/MusicAlbum provider.

The `upstream` remote is fetch-only. To synchronize it:

```powershell
git fetch upstream master
git merge upstream/master
```

Releases use the repository's `VERSION` file and independent `concerts-vX.Y.Z` tags, avoiding collisions with tags
inherited from upstream. A release is complete only when the versioned ZIP, checksum, and matching Install URL have been
written to the public plugin repository. Version, assembly version, `build.yaml`, tag, ZIP name, and manifest entry must
agree.

After a merge, the tests inspect the compiled assembly's discovery surface and fail if an upstream Artist/MusicAlbum provider or an unapproved discovery type becomes registered. The only permitted BoxSet metadata provider is the concert-member-gated provider described above. The standalone plugin name, assembly name, GUID, and Movie external-ID key remain independent of the official plugin.

Licensed under GPL-3.0.
