# Jellyfin VGMdb Concerts

A standalone Jellyfin 10.11 metadata provider for Japanese concert Blu-rays and DVDs catalogued by VGMdb.

`VGMdb Concerts` has its own plugin GUID, assembly, provider name, and Movie external ID. It can be installed alongside Jellyfin's official `VGMdb` music plugin. This plugin does not register Artist or MusicAlbum providers.

## Concert movie features

- Searches VGMdb albums from a Jellyfin **Movies** library.
- Filters automatic matches to releases carrying both live and video signals.
- Maps title, original Japanese title, release date, overview, genres, studios, catalog number, media format, and publish format.
- Maps VGMdb performers to Jellyfin people so a performer can link multiple concerts.
- Provides the primary cover and a clickable VGMdb Movie external ID.
- Prefers Japanese names when the library metadata language is `ja`; otherwise prefers romanized and English names.
- Supports an exact folder/file hint such as `[vgmdbid-116768]`.
- Ranks catalog-number matches first, followed by exact title, year, and partial title matches.
- Fuzzy-ranks remaining results by the best Levenshtein similarity across Japanese, romanized, English, and fallback titles.
- Optionally uses AnitomySharp to derive an additional query from automatic Movie file names. It is disabled by default,
  never parses manual searches or explicit VGMdb IDs, retains the original query, merges duplicate VGMdb releases, and
  confidence-penalizes parsed-title matches before applying the existing ranking rules.
- Caches successful VGMdb and Bangumi searches/details in a bounded in-memory cache by default. Concurrent identical
  requests are coalesced, successful entries expire after at most seven days with a six-hour sliding window, and failed
  responses are never cached. A VGMdb transport failure starts a two-minute cooldown so a library scan does not repeat
  the same unreachable-host request for every file.
- Supplements successful VGMdb matches from high-confidence Bangumi event subjects by default. VGMdb remains authoritative
  for commercial release identity, title, date, catalog data, format, and primary cover. Bangumi may add an event summary,
  event date tag, venue, tags, collection name for an identified Day, IDs, links, and landscape artwork. Any Bangumi
  network, JSON, timeout, or confidence failure leaves the complete VGMdb result unchanged.
- Optionally falls back for unlisted event recordings, including multi-day streaming archives and standalone concert
  folders. It is disabled by default and runs only after VGMdb
  returns no eligible concert video, or VGMdb is unavailable, for a Movie title containing both an explicit Day number
  and an Archive/アーカイブ marker. Automatic scans and metadata refreshes may use this fallback, while manual Identify
  searches remain unparsed. If another provider has already normalized the displayed title and removed those markers,
  automatic refreshes recover them from the source filename. It preserves separate day movies, assigns a shared Jellyfin
  collection name, and never invents a VGMdb ID or commercial-release metadata.
- Recognizes local concert companion files during automatic scans and metadata refreshes by default, without changing
  manual Identify searches. Normal Day discs still prefer an eligible VGMdb release; Making of, backstage, メイキング,
  舞台裏, 幕后, and 花絮 files are classified as `BehindTheScenes`, while numbered discs carrying an explicit bonus,
  documentary, vacation, or 特典 signal are classified as `Featurette`. These items retain their own playable Movie
  entries and inherit the cleaned concert-folder collection identity.
- Optionally enriches that archive fallback from Bangumi event subjects. This second switch is also disabled by default.
  Only high-confidence type `演出` matches with a compatible year and the required episode coverage are accepted.
  Standalone events retain a single Movie identity and do not receive an invented Day suffix or collection. Bangumi can supply the
  event date, summary, per-day performer and setlist text, venue, landscape artwork, tags, subject/episode IDs, and external links.
  Network, JSON, or confidence failures preserve the pure local archive fallback instead of failing metadata refresh.
- Provides TMDb-style metadata for generated concert `BoxSet` items. It accepts only collections with members identified
  by VGMdb Concerts, writes an independent stable collection ID, and aggregates the collection title, overview, first
  event date, year, genres, studios, and collection tags from those members.

VGMdb describes the commercial video release, not necessarily the original performance date or venue. Those event-level fields remain suitable for a future LiveFans/local-NFO integration.

## Recommended Jellyfin layout

Create a Movies library and keep one concert release per folder:

```text
Concerts/
└── THE IDOLM@STER SHINY COLORS 3rdLIVE TOUR NAGOYA (2022) [vgmdbid-116768]/
    └── THE IDOLM@STER SHINY COLORS 3rdLIVE TOUR NAGOYA (2022) [vgmdbid-116768].mkv
```

Set the library's preferred metadata language to Japanese if Japanese titles and performer names should be used. In the library metadata provider settings, enable and order **VGMdb Concerts** as desired.

The optional AnitomySharp parser can be enabled under **Dashboard → Plugins → VGMdb Concerts**. It is most useful for
file names containing release groups, resolutions, codecs, and source tags. Keep it disabled when concert titles contain
unusual numbering that should be passed to VGMdb unchanged.

The event archive fallback can be enabled on the same plugin page. For example, these automatic Movie titles are kept
as separate items and assigned the shared collection `THE IDOLM@STER SHINY COLORS LIVE FUN!! -Beyond the Blue sky-`:

```text
THE IDOLM@STER SHINY COLORS LIVE FUN!! -Beyond the Blue sky- Day 1 (アーカイブ)
THE IDOLM@STER SHINY COLORS LIVE FUN!! -Beyond the Blue sky- Day 2 (アーカイブ)
```

Version 1.7.7 also applies the same optional fallback to a standalone concert folder when no VGMdb concert-video release
matches. For example, `Ave Mujica 0th LIVE「Primo die in scaena」` can be matched to a high-confidence Bangumi `演出`
subject and receive its localized title, original title, date, overview, tags, IDs, link, and artwork. Matching remains
generic: no artist, concert title, or Bangumi subject ID is embedded in production code. Release-group and technical
brackets are removed before matching, and a Bangumi/network/confidence failure keeps the cleaned local concert metadata.

The plugin deliberately does not install a second filesystem watcher. Jellyfin's library **Enable real time monitoring**
option watches supported folders and starts the incremental library scan; VGMdb Concerts participates as a Movie provider,
then runs its collection/identity repair after the scan. This avoids duplicate watchers and duplicate scans. For network
shares or filesystems whose change notifications are unavailable, keep Jellyfin's scheduled library scan enabled.

Version 1.7.5 lets both Movie and collection artwork reuse a numeric `Bangumi` ID written by the official Bangumi
plugin. When collection members still have no remote image identity, the collection image provider performs its own
Bangumi event search using the canonical collection title and year, with the same event-type and title-confidence
checks used for metadata. Generated collections receive a one-time stale-image reset after upgrading. This is generic
collection behavior; no artist, tour, quadrant, or subject ID is embedded in production code.

Version 1.7.4 accepts both scalar and structured-array Bangumi infobox values, so event subjects such as IWSF no longer
abort deserialization. Generic Day companion items now use the same optional Bangumi enrichment and confidence checks as
archive files, and an existing numeric Bangumi subject ID may be reused after event type, year, and Day coverage are
validated. VGMdb Concerts has first priority for its managed Movie artwork. On the first scan after upgrading, managed
local-fallback concerts with a trusted VGMdb/Bangumi identity discard unrelated IMDb/TMDb/TVDb identities and refresh
their artwork once; this replaces previously persisted actor-collage and video-frame posters without repeatedly
overwriting later user choices.

Version 1.7.3 recognizes generic festival markers such as `FES`, `フェス`, and `歌合戦`, recovers the event year from
dated release folders, and accepts Day markers before stream variants such as `DAY1 SW` or `DAY1 定点`. Release-group
and codec tags no longer leak into Movie titles. The post-scan repair also restores per-leg titles (for example,
`Brilliant Blooms Day 1`) when an album-level VGMdb match previously gave every disc the same release title.

Version 1.7.2 uses the nearest concert parent folder as the stable collection identity. Bangumi supplementation may
localize individual Movie titles, but it no longer replaces that identity or creates a second collection. For example,
`シャイニーカラーズ8th Day 1（アーカイブ）` below
`[260425-26] THE IDOLM@STER SHINY COLORS ∞th LIVE iと夢 (ASOBI)` is grouped under the cleaned canonical collection
`THE IDOLM@STER SHINY COLORS ∞th LIVE iと夢`. More specific file titles such as `Brilliant Blooms Day 1` remain the
individual Movie titles, while all discs and making-of items below the same release folder share one collection.
Automatic VGMdb matching also queries this stable parent release in addition to the specific file title.

The companion fallback is enabled by default on the same configuration page. It walks through intermediate `Disc N`
folders to find the nearest concert root, so `Disc 3/Making of ... Day 1.mkv` is marked Behind the Scenes and
`Disc 7 - Shinymas's Summer Vacation in Okinawa.mkv` is marked Featurette. Explicit VGMdb IDs remain authoritative.
For items previously identified incorrectly by another provider, refresh with **Replace all metadata** once so stale
provider IDs do not keep that old manual identification.

The Movies library must also have **Automatically add to collections** enabled. Jellyfin creates the collection after
at least two movies with the same generated collection name have completed metadata refresh and a subsequent full
library scan. An individual **Refresh metadata** operation writes `CollectionName` but does not run Jellyfin's
`CollectionPostScanTask`, so refresh both Day items and then run **Scan All Libraries** once. Day files remain separate
playable Movies inside the generated collection rather than being treated as alternate versions of one Movie.
After each full scan, the plugin reconciles identified concert Movies against that stable folder identity. It moves
members out of obsolete plugin-generated per-file collections, removes an obsolete collection once it is empty, and
clears local image database entries whose referenced files no longer exist before asking Jellyfin to refresh them.

The separate Bangumi enrichment checkbox uses Bangumi only inside this archive fallback. It does not replace VGMdb for
commercial Blu-ray/DVD releases. The original event title and a punctuation-simplified additional query are both sent,
then their candidates are merged by subject ID. Results remain constrained to event subjects and are ranked locally by
normalized title, year, and episode coverage before the selected Day is fetched. The plugin sends the identifiable,
versioned User-Agent required by the Bangumi API. If Bangumi is unavailable or neither query passes the confidence checks,
the same movies still receive the local title, year, genres, tags, and collection name from the archive fallback. Movies
previously identified by the pure local fallback are enriched in place on their next metadata refresh; deleting metadata
or re-importing files is not required.

The query cache follows the successful-response cache used by the Bangumi Jellyfin plugin, while adding in-flight
request coalescing and a short VGMdb failure cooldown. It is process-local, has a 512-entry bound, is cleared on Jellyfin
restart, and can be disabled under **Dashboard → Plugins → VGMdb Concerts**. Disabling it also disables the cooldown.

Jellyfin marks an interactive **Refresh metadata** request as non-automated; the plugin handles that refresh path
explicitly without exposing parsed archive fallback entries in the manual **Identify** search result list.
Version 1.5.2 also reads the source filename during that refresh when the stored display title no longer contains
`Day` and `アーカイブ`; this is required after another metadata provider has renamed an item. A `生放送` file does not
qualify for the archive fallback and remains an independent Movie.

Image selection is slot-aware: a VGMdb release cover is preferred for Primary while Bangumi event artwork is preferred
for Backdrop and Thumb. If no source supplies artwork for a requested shape, the available artwork is also exposed for
that slot and Jellyfin crops it to the target card shape. Local `poster`, `landscape`, and `backdrop` files still take
precedence over remote providers.

Automatically created collections are separate `BoxSet` items and do not inherit their movies' metadata or artwork.
Following Jellyfin's TMDb BoxSet design, VGMdb Concerts first identifies and populates a narrowly scoped concert
collection, then resolves its images. Remote VGMdb/Bangumi artwork remains preferred. If those sources have no usable
image, a dynamic fallback reuses the first already-downloaded local image from an identified member Movie. Primary,
Backdrop, and Thumb retain slot-aware selection and crop fallback. Refresh the collection's metadata and images once
after updating the plugin.

## Install

The recommended installation method follows Jellyfin's plugin-repository workflow and uses GitHub only:

1. In the Jellyfin dashboard, open **Plugins → Repositories** and select **Add**.
2. Set the repository name to `VGMdb Concerts`.
3. Set the repository URL to:

   ```text
   https://wym3253.github.io/jellyfin-plugin-vgmdb-concerts-repository/repository.json
   ```

4. Save, open **Catalog**, find **VGMdb Concerts**, and install it.
5. Restart Jellyfin after installation or update.

Installing through the catalog allows Jellyfin to discover later releases published by this repository. The private source repository publishes only the catalog manifest and compiled ZIP files to a dedicated public GitHub repository through GitHub Pages. If GitHub Pages is unavailable in a particular network, the raw GitHub URL remains a fallback:

```text
https://raw.githubusercontent.com/wym3253/jellyfin-plugin-vgmdb-concerts-repository/main/repository.json
```

## Build and test

The plugin targets .NET 9 and Jellyfin 10.11. GitHub Actions performs the authoritative build on every push and pull request:

1. Open the repository's **Actions** page.
2. Select the latest successful **Build and test** run.
3. Download the `Jellyfin.Plugin.Vgmdb-Concerts-*` artifact.
4. Copy `Jellyfin.Plugin.VgmdbConcerts.dll` into a dedicated directory below Jellyfin's plugins directory and restart Jellyfin.

The workflow restores dependencies, runs the complete test project in Release mode, publishes the plugin, and retains the downloadable artifact for 30 days. It can also be started manually with **Run workflow**.

## Data source note

The plugin uses the community-operated `vgmdb.info` JSON API, because VGMdb does not publish an official API. Optional
event archive enrichment uses the official anonymous [Bangumi API](https://bangumi.github.io/api/) with project
attribution in its User-Agent. Service availability, user-contributed metadata, image hosting, and upstream schema
changes are outside this plugin's control.

## Upstream and license

Based on [jellyfin/jellyfin-plugin-vgmdb](https://github.com/jellyfin/jellyfin-plugin-vgmdb). The complete upstream runtime source is retained so upstream can be fetched and merged normally. The project file excludes upstream Artist/MusicAlbum discovery types and the upstream plugin entry point from this standalone assembly. The built DLL registers Movie metadata, image, external-ID, and external-URL providers, metadata and image providers restricted to BoxSets generated from identified concert Movies, and a post-scan repair limited to those identified Movies and managed BoxSets; it does not register any Artist/MusicAlbum provider.

The `upstream` remote is fetch-only. To synchronize it:

```powershell
git fetch upstream master
git merge upstream/master
```

The **Sync upstream** GitHub Actions workflow also checks for upstream changes every day at 00:17 JST and can be started manually. It merges `upstream/master`, increments the standalone patch version, restores dependencies, and runs the complete test suite before pushing to this repository's `master` branch. When there is no upstream update it creates no commit; merge conflicts or failed tests stop the workflow without pushing.

Releases use the repository's `VERSION` file and independent tags such as `concerts-v1.0.0`, avoiding collisions with tags inherited from upstream. Each successful upstream merge publishes the next patch version as a GitHub Release with a versioned ZIP package. A rerun also repairs a missing Release for the current version without creating another source commit. The workflow refuses to publish if `VERSION`, the assembly version, and `build.yaml` disagree.

After a merge, the tests inspect the compiled assembly's discovery surface and fail if an upstream Artist/MusicAlbum provider or an unapproved discovery type becomes registered. The only permitted BoxSet metadata provider is the concert-member-gated provider described above. The standalone plugin name, assembly name, GUID, and Movie external-ID key remain independent of the official plugin.

Licensed under GPL-3.0.
