# Jellyfin VGMdb Concerts

[English](README.md) | [简体中文](README.zh-CN.md)

A Movie metadata and artwork plugin for Jellyfin 12.1 that identifies Japanese concert videos: Blu-ray/DVD rips, Day recordings, extras, and streaming archives. Bangumi is the main source; VGMdb adds release details. It does not register music providers, so it can run next to Jellyfin's official VGMdb plugin.

> **No compatibility between versions.** Any release may change settings, stored provider IDs, and collection handling without migrating existing data. After upgrading, wait for the library scan to finish and run the repair task (see [Repair task](#repair-task)). To go back, install an older package from the repository.

## Install

In Jellyfin, open **Dashboard → Plugins → Repositories → Add** and add:

```text
https://wym3253.github.io/jellyfin-plugin-vgmdb-concerts-repository/repository.json
```

Install **VGMdb Concerts** from the catalog and restart Jellyfin. If GitHub Pages is unreachable, use `https://raw.githubusercontent.com/wym3253/jellyfin-plugin-vgmdb-concerts-repository/main/repository.json`. Every published version stays downloadable for rollback.

## How items are matched

1. **Bangumi first.** The plugin searches Bangumi for a performance (演出) subject whose title and year match. A Day recording also needs the matching Bangumi episode. Bangumi supplies the title, date, description, tags, venue, links, and cover.
2. **Wikidata aliases (optional).** If an English title finds nothing, Japanese aliases from Wikidata are used for another Bangumi search. Wikidata never supplies metadata or images.
3. **VGMdb supplement (optional).** For a verified match, VGMdb adds catalog number, media format, studios, performers, and a backup cover. If Bangumi has no match, a matching VGMdb concert video can be used instead.
4. **Local fallback.** If nothing matches, recognized concert folders and Day archives still get local titles and a collection.

Stored IDs are revalidated before reuse. Ordinary movies are never claimed just because their path looks like a concert.

## Library layout

Use a Movies library with one concert per folder. The folder name becomes the collection name.

- A folder is recognized as a concert when its name contains a concert word such as `LIVE`, `Concert`, `FES`, `ライブ`, `公演`, or `フェス`.
- A folder without such a word is recognized when its files repeat the folder title plus a part marker (`Day1`, `Disc 2`, `Menu 01`, `Bonus 03`) and Bangumi confirms the title and year as a performance. For example, `[Group] THE IDOLM@STER M@STERS OF IDOL WORLD!! 2015 [BDRip]/[Group] THE IDOLM@STER M@STERS OF IDOL WORLD!! 2015 - Day1 Disc1.mkv`. Confirmed titles are listed in the settings.
- File names should keep `Day 1` / `Day 2` markers. Streaming archives also need `Archive` or `アーカイブ`.
- Making-of, bonus, menu, and extra disc files are kept as separate items in the same collection and use the event cover.

## Settings

**Dashboard → Plugins → VGMdb Concerts.** The page follows Jellyfin's language (English or Simplified Chinese).

| Setting | Default | Purpose |
| --- | --- | --- |
| Enable VGMdb | On | Turn off to skip all VGMdb requests and cached VGMdb results. Bangumi, local recognition, and repair keep working. |
| Bangumi / VGMdb addresses | `api.bgm.tv`, `bgm.tv` / `vgmdb.info`, `vgmdb.net` | API and link base addresses. |
| Request timeout in seconds | 15 | Per attempt, up to three attempts for temporary failures. |
| HTTP proxy address | Empty | Proxy used only by this plugin. |
| Cache successful queries | On | Shares responses between files. Empty search results are never cached, searches expire after 15 minutes, and a manual **Refresh metadata** ignores older entries. |
| Look up Japanese title aliases in Wikidata | On | Allows the Wikidata alias lookup. |
| Use AnitomySharp for automatic file-name searches | Off | Adds one extra VGMdb query built from the parsed file name. |
| Trust an existing ID from the official Bangumi plugin | Off | Reuses that ID only after it passes the same checks. |
| Bangumi-verified concert folders | Empty | Filled automatically, one folder title per line. Delete a line to stop treating that folder as a concert. |
| Local concert title mappings | Empty | Manual links from a folder title to a Bangumi subject; see below. |
| Recognize concert discs, making-of videos, and bonus features | On | Recognizes Day discs, extra discs, making-of, bonus, and menu files. |
| Group unlisted multi-day concert archives into collections | On | Keeps unmatched Day archives and standalone events as local items. |

The VGMdb service at `vgmdb.info` has closed. Turn off **Enable VGMdb** unless you configure a working compatible API.

## Title mappings

Use a mapping when a translated or romanized folder title cannot be matched automatically and you know the Bangumi subject. Enter one line per concert:

```text
City Orchestra Winter LIVE = https://bangumi.tv/subject/12345
Harbor Ensemble Summer Concert = 67890
```

- The left side is the folder name without release-group and format tags: `[Release] City Orchestra Winter LIVE [BDRip 1080p]` becomes `City Orchestra Winter LIVE`. Case, full-width characters, and repeated spaces are ignored.
- The right side is a subject ID or a `/subject/<id>` link on `bangumi.tv`, `bgm.tv`, or `chii.in`.
- One line covers every Day, extra, and the collection of that folder. Two different IDs for the same title are rejected.
- A mapping only skips the title comparison: the subject must still be a performance with a matching year, and Day files still need their episodes.

## Repair task

**Dashboard → Scheduled Tasks → VGMdb Concerts → Repair VGMdb Concerts collections and artwork** runs only when started manually, and only touches this plugin's items. It:

- rebuilds collection membership from the concert folders, merging duplicates and deleting empty collections the plugin created;
- removes cast entries that are not performers;
- restores missing covers and refreshes items whose mapping or identity changed.

Run it after upgrading, after changing mappings, or when collections or covers look wrong. To pick a cover again for a single item, use **Refresh metadata** with **Replace existing images** on that item.

## Troubleshooting

**Missing covers.** Check access to `api.bgm.tv` and `lain.bgm.tv`, and that Jellyfin's metadata folder is writable and persistent. The log records where each cover is saved. If neither source has an image, Jellyfin may fall back to a video frame.

**ASS subtitles shown as boxes.** The subtitle renderer is missing a CJK font. On the Jellyfin server, install a fallback font:

```bash
sudo install -d -m 755 /usr/local/share/fonts/jellyfin-noto
sudo curl --fail --location --retry 2 \
  https://raw.githubusercontent.com/notofonts/noto-cjk/main/Sans/OTF/SimplifiedChinese/NotoSansCJKsc-Regular.otf \
  --output /usr/local/share/fonts/jellyfin-noto/NotoSansCJKsc-Regular.otf
sudo chmod 644 /usr/local/share/fonts/jellyfin-noto/NotoSansCJKsc-Regular.otf
sudo fc-cache -f /usr/local/share/fonts/jellyfin-noto
```

Then set **Dashboard → Playback → Transcoding → Fallback font folder path** to that folder (the container path, if Jellyfin runs in a container), enable fallback fonts, and restart playback. Keep the folder under 20 MiB. If boxes remain, change the subtitle styles' font to `Noto Sans CJK SC`, or set **Burn subtitles** to **All complex formats** (this costs server transcoding). See Jellyfin's [font guide](https://jellyfin.org/docs/general/administration/configuration#fonts).

## Development

Based on [jellyfin/jellyfin-plugin-vgmdb](https://github.com/jellyfin/jellyfin-plugin-vgmdb); the upstream music sources stay in the repository for merging but are not compiled. Builds, tests, and releases run only in manually triggered GitHub Actions workflows. Compatibility with earlier versions is not a goal: changes may rename settings or stored IDs freely.
