# Jellyfin VGMdb Concerts

[English](README.md) | [简体中文](README.zh-CN.md)

适用于 Jellyfin 12.1 的电影元数据和封面插件，用于识别日本演唱会视频：BD/DVD 压制、各 Day 录像、特典和配信アーカイブ。以 Bangumi 为主要来源，VGMdb 补充发行信息。插件不注册音乐提供程序，可与 Jellyfin 官方 VGMdb 插件共存。

> **各版本之间不保持兼容。** 任何版本都可能修改设置、已保存的提供程序 ID 和合集处理方式，且不迁移已有数据。升级后请等待媒体库扫描完成，再运行修复任务（见[修复任务](#修复任务)）。如需回退，从插件仓库安装旧版本。

## 安装

在 Jellyfin 中打开 **控制台 → 插件 → 存储库 → 添加**，填入：

```text
https://wym3253.github.io/jellyfin-plugin-vgmdb-concerts-repository/repository.json
```

在目录中安装 **VGMdb Concerts** 并重启 Jellyfin。GitHub Pages 无法访问时，可改用 `https://raw.githubusercontent.com/wym3253/jellyfin-plugin-vgmdb-concerts-repository/main/repository.json`。所有已发布版本都保留下载，便于回退。

## 匹配方式

1. **优先 Bangumi。** 搜索标题和年份相符的“演出”条目；Day 录像还需要对应的 Bangumi 剧集。标题、日期、简介、标签、场馆、链接和封面均来自 Bangumi。
2. **Wikidata 别名（可选）。** 英文标题搜不到时，用 Wikidata 的日文别名再搜一次 Bangumi。Wikidata 不提供元数据或图片。
3. **VGMdb 补充（可选）。** 已验证的匹配会由 VGMdb 补充型号、媒体格式、厂牌、演出者和备用封面。Bangumi 无结果时，可使用相符的 VGMdb 演唱会视频。
4. **本地后备。** 都匹配不到时，已识别的演唱会文件夹和 Day 配信仍会获得本地标题和合集。

已保存的 ID 会先重新验证再使用。普通电影不会仅因路径像演唱会而被插件接管。

## 媒体库结构

使用“电影”媒体库，每个演唱会一个文件夹，文件夹名即合集名。

- 文件夹名含有 `LIVE`、`Concert`、`FES`、`ライブ`、`公演`、`フェス` 等演唱会词语时，会被识别为演唱会。
- 不含这类词语的文件夹，若其中文件名重复文件夹标题并带有分段标记（`Day1`、`Disc 2`、`Menu 01`、`Bonus 03`），且 Bangumi 确认该标题和年份属于演出条目，也会被识别。例如 `[Group] THE IDOLM@STER M@STERS OF IDOL WORLD!! 2015 [BDRip]/[Group] THE IDOLM@STER M@STERS OF IDOL WORLD!! 2015 - Day1 Disc1.mkv`。确认过的标题会列在设置中。
- 文件名请保留 `Day 1` / `Day 2` 标记；配信アーカイブ还需含 `Archive` 或 `アーカイブ`。
- 幕后花絮、特典、菜单和附加光盘作为同一合集中的独立条目，使用活动封面。

## 设置

**控制台 → 插件 → VGMdb Concerts**。页面跟随 Jellyfin 界面语言（英文或简体中文）。

| 设置 | 默认 | 作用 |
| --- | --- | --- |
| 启用 VGMdb | 开启 | 关闭后跳过所有 VGMdb 请求及其缓存结果；Bangumi、本地识别和修复照常工作。 |
| Bangumi / VGMdb 地址 | `api.bgm.tv`、`bgm.tv` / `vgmdb.info`、`vgmdb.net` | API 与链接的基础地址。 |
| 请求超时秒数 | 15 | 每次尝试的时限，临时故障最多尝试三次。 |
| HTTP 代理地址 | 留空 | 仅本插件使用的代理。 |
| 缓存成功的 VGMdb 和 Bangumi 查询 | 开启 | 在文件之间共享响应。空搜索结果从不缓存，搜索结果 15 分钟后过期，手动“刷新元数据”会忽略之前的缓存。 |
| 从 Wikidata 查询日文标题别名 | 开启 | 允许查询 Wikidata 别名。 |
| 使用 AnitomySharp 自动解析文件名搜索 | 关闭 | 根据解析出的文件名额外发起一次 VGMdb 查询。 |
| 信任 Bangumi 官方插件已有的 ID | 关闭 | 该 ID 通过同样的验证后才会复用。 |
| 经 Bangumi 验证的演唱会文件夹 | 留空 | 自动填写，每行一个文件夹标题；删除某行即不再将该文件夹视为演唱会。 |
| 本地演唱会标题映射 | 留空 | 手动将文件夹标题关联到 Bangumi 条目，见下文。 |
| 识别演唱会分碟、幕后花絮和特典内容 | 开启 | 识别 Day 光盘、附加光盘、幕后花絮、特典和菜单文件。 |
| 将未收录的多日演唱会归档分组为合集 | 开启 | 未匹配的 Day 配信和独立活动保留为本地条目。 |

`vgmdb.info` 服务已关闭。除非配置了可用的兼容 API，否则请关闭**启用 VGMdb**。

## 标题映射

翻译或罗马字的文件夹标题无法自动匹配、而你已知道 Bangumi 条目时使用。每个演唱会一行：

```text
City Orchestra Winter LIVE = https://bangumi.tv/subject/12345
Harbor Ensemble Summer Concert = 67890
```

- 左侧为去掉发布组和格式标签后的文件夹名：`[Release] City Orchestra Winter LIVE [BDRip 1080p]` 写作 `City Orchestra Winter LIVE`。忽略大小写、全角字符和多余空格。
- 右侧为条目 ID，或 `bangumi.tv`、`bgm.tv`、`chii.in` 上的 `/subject/<id>` 链接。
- 一行覆盖该文件夹的全部 Day、特典和合集。同一标题对应两个不同 ID 时，映射被拒绝。
- 映射只跳过标题比较：条目仍须是年份相符的演出，Day 文件仍须有对应剧集。

## 修复任务

**控制台 → 计划任务 → VGMdb Concerts → 修复 VGMdb Concerts 合集与封面** 只在手动启动时运行，且只处理本插件的条目。它会：

- 按演唱会文件夹重建合集成员，合并重复合集，并删除插件自己创建的空合集；
- 移除非演出者的演职员；
- 补回缺失的封面，并刷新映射或身份发生变化的条目。

升级后、修改映射后，或合集和封面异常时运行。若要为单个条目重新选择封面，对该条目执行“刷新元数据”并勾选“替换现有图片”。

## 常见问题

**封面缺失。** 检查能否访问 `api.bgm.tv` 和 `lain.bgm.tv`，以及 Jellyfin 元数据目录是否可写且持久。日志会记录每个封面的保存位置。两个来源都没有图片时，Jellyfin 可能改用视频帧。

**ASS 字幕显示为方框。** 字幕渲染器缺少中日文字体。在 Jellyfin 服务器上安装后备字体：

```bash
sudo install -d -m 755 /usr/local/share/fonts/jellyfin-noto
sudo curl --fail --location --retry 2 \
  https://raw.githubusercontent.com/notofonts/noto-cjk/main/Sans/OTF/SimplifiedChinese/NotoSansCJKsc-Regular.otf \
  --output /usr/local/share/fonts/jellyfin-noto/NotoSansCJKsc-Regular.otf
sudo chmod 644 /usr/local/share/fonts/jellyfin-noto/NotoSansCJKsc-Regular.otf
sudo fc-cache -f /usr/local/share/fonts/jellyfin-noto
```

然后在 **控制台 → 播放 → 转码 → 后备字体文件夹路径** 中填入该目录（容器部署时填容器内路径），启用后备字体，再重新播放。该目录总大小须小于 20 MiB。若仍显示方框，将字幕样式字体改为 `Noto Sans CJK SC`，或把**烧录字幕**设为**所有复杂格式**（会占用服务器转码资源）。参见 Jellyfin [字体说明](https://jellyfin.org/docs/general/administration/configuration#fonts)。

## 开发

基于 [jellyfin/jellyfin-plugin-vgmdb](https://github.com/jellyfin/jellyfin-plugin-vgmdb)；上游音乐源码保留在仓库中以便合并，但不参与编译。构建、测试和发布只在手动触发的 GitHub Actions 工作流中进行。不以兼容旧版本为目标：修改可以自由重命名设置或已保存的 ID。
